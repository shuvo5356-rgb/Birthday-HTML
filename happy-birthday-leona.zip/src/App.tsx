import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Heart, Music, Volume2, VolumeX, Clock, Gift, Sparkles, 
  Mail, ArrowDown, Languages, Compass, Award, Star, Laugh, MessageSquare 
} from 'lucide-react';

import { translations, timelineEvents, gallerySlides, polaroidPhotos, initialNotes } from './translations';
import { Language } from './types';
import { audioSynth } from './utils/audioSynth';

import FallingPetals from './components/FallingPetals';
import LockScreen from './components/LockScreen';
import CinematicIntro from './components/CinematicIntro';
import BirthCalendar from './components/BirthCalendar';
import PolaroidWall from './components/PolaroidWall';
import LoveWorld from './components/LoveWorld';
import OurMoments from './components/OurMoments';
import MagicDust from './components/MagicDust';
import ParticleHeart from './components/ParticleHeart';
import InteractiveTreasure from './components/InteractiveTreasure';
import FireworksCanvas, { FireworksRef } from './components/FireworksCanvas';

export default function App() {
  const [lang, setLang] = useState<Language>('en'); // Default to English as requested
  const [unlocked, setUnlocked] = useState(false);
  const [introComplete, setIntroComplete] = useState(false);
  const [musicPlaying, setMusicPlaying] = useState(false);
  
  // App loaded loader state
  const [appLoaded, setAppLoaded] = useState(false);

  // Countdown State
  const [countdown, setCountdown] = useState({
    days: '00',
    hours: '00',
    minutes: '00',
    seconds: '00'
  });

  // Typewriter typing effect
  const [typewriterText, setTypewriterText] = useState('');

  // Active timeline background index
  const [timelineBgIndex, setTimelineBgIndex] = useState(0);

  // Gallery active slideshow index
  const [activeSlide, setActiveSlide] = useState(0);

  // Lightbox Image View
  const [lightboxImg, setLightboxImg] = useState<string | null>(null);

  // Secret Letter Open
  const [letterOpen, setLetterOpen] = useState(false);

  // Birthday cake candle state
  const [candleBlown, setCandleBlown] = useState(false);
  const [cakeMsg, setCakeMsg] = useState('');
  const [floatingWishes, setFloatingWishes] = useState<{ id: number; text: string; textBn: string }[]>([]);

  // Ref to Fireworks Canvas
  const fireworksRef = useRef<FireworksRef | null>(null);

  const t = translations[lang];

  // 1. Initial Page loader simulation
  useEffect(() => {
    const timer = setTimeout(() => {
      setAppLoaded(true);
    }, 2500);
    return () => clearTimeout(timer);
  }, []);

  // 2. Play Background Music loop controlled by React state
  useEffect(() => {
    if (musicPlaying && unlocked && introComplete) {
      audioSynth.start();
    } else {
      audioSynth.stop();
    }
  }, [musicPlaying, unlocked, introComplete]);

  // 3. Countdown timer calculations to her birthday (July 4, next occurrence)
  useEffect(() => {
    const updateCountdown = () => {
      const now = new Date();
      let currentYear = now.getFullYear();
      let bday = new Date(currentYear, 6, 4); // July 4 (months are 0-indexed, so 6 = July)
      
      if (now > bday) {
        bday.setFullYear(currentYear + 1);
      }
      
      const diff = bday.getTime() - now.getTime();
      
      if (diff <= 0) {
        setCountdown({ days: '🎂', hours: '00', minutes: '00', seconds: '00' });
        return;
      }

      const d = Math.floor(diff / (1000 * 60 * 60 * 24));
      const h = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const m = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const s = Math.floor((diff % (1000 * 60)) / 1000);

      setCountdown({
        days: String(d).padStart(2, '0'),
        hours: String(h).padStart(2, '0'),
        minutes: String(m).padStart(2, '0'),
        seconds: String(s).padStart(2, '0')
      });
    };

    updateCountdown();
    const interval = setInterval(updateCountdown, 1000);
    return () => clearInterval(interval);
  }, []);

  // 4. Typewriter Typing Effect for Hero Section
  useEffect(() => {
    if (!introComplete) return;

    const fullMessage = "Happy Birthday My Love LEONA ❤️";

    let index = 0;
    setTypewriterText('');
    
    const interval = setInterval(() => {
      if (index <= fullMessage.length) {
        setTypewriterText(fullMessage.slice(0, index));
        index++;
      } else {
        clearInterval(interval);
      }
    }, 75);

    return () => clearInterval(interval);
  }, [introComplete]);

  // 5. Scroll timeline backdrop handler
  useEffect(() => {
    if (!introComplete) return;

    const handleScroll = () => {
      const timelineSection = document.getElementById('timeline');
      if (!timelineSection) return;

      const rect = timelineSection.getBoundingClientRect();
      const totalHeight = rect.height;
      const scrolled = -rect.top;
      
      let progress = scrolled / (totalHeight - window.innerHeight);
      progress = Math.max(0, Math.min(1, progress));

      // 10 background images
      const idx = Math.min(9, Math.floor(progress * 10));
      setTimelineBgIndex(idx);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [introComplete]);

  // 6. Automatically rotate photo gallery slides
  useEffect(() => {
    if (!introComplete) return;
    const interval = setInterval(() => {
      setActiveSlide((prev) => (prev + 1) % gallerySlides.length);
    }, 3500);
    return () => clearInterval(interval);
  }, [introComplete]);

  // Handler for custom actions
  const handleUnlock = () => {
    setUnlocked(true);
    setMusicPlaying(true); // Automatically play sweet chimes on unlock
  };

  const handleIntroComplete = () => {
    setIntroComplete(true);
  };

  const extraWishesList = [
    {
      en: "May your beautiful smile always light up the world, Leona! 🌟",
      bn: "তোমার মিষ্টি হাসি যেন সারাজীবন পৃথিবীকে আলো করে রাখে, লিওনা! 🌟"
    },
    {
      en: "Wishing you a year filled with sweet books, warm coffee, and cozy sunsets. ☕📚🌅",
      bn: "বই, কফি আর সুন্দর সূর্যাস্তে ঘেরা হোক তোমার প্রতিটি দিন। ☕📚🌅"
    },
    {
      en: "You deserve all the happiness in the universe. Happy Birthday, my love! ❤️",
      bn: "তুমি পৃথিবীর সব সুখের যোগ্য। শুভ জন্মদিন, আমার ভালোবাসা! ❤️"
    },
    {
      en: "Every heartbeat of mine sings a wish for your happiness. 🌸",
      bn: "আমার প্রতিটি হৃদস্পন্দন শুধু তোমার সুখের প্রার্থনা করে। 🌸"
    },
    {
      en: "To the girl who filled my life with magic and cozy moments—Happy Birthday! 🎈",
      bn: "যে মেয়েটি আমার জীবনকে এক মায়াবী জাদুতে ভরিয়ে দিয়েছে—তাকে জানাই শুভ জন্মদিন! 🎈"
    },
    {
      en: "Holding your hand is my favorite place in the world. Have the best birthday! 💖",
      bn: "তোমার হাতটি ধরে থাকা আমার পৃথিবীর সবচেয়ে প্রিয় জায়গা। তোমার দিনটি কাটুক অনেক আনন্দে! 💖"
    }
  ];

  const triggerFloatingWish = () => {
    const randomWish = extraWishesList[Math.floor(Math.random() * extraWishesList.length)];
    const newWish = {
      id: Date.now() + Math.random(),
      text: randomWish.en,
      textBn: randomWish.bn
    };
    setFloatingWishes((prev) => [...prev, newWish]);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
      setFloatingWishes((prev) => prev.filter((w) => w.id !== newWish.id));
    }, 5000);
  };

  const handleBlowCandle = () => {
    if (candleBlown) {
      // Allow extra clicks to trigger floating wishes offering extra birthday wishes
      triggerFloatingWish();
      return;
    }
    setCandleBlown(true);

    // Play physical sound effects
    audioSynth.playCandleBlowEffect();

    // Trigger fireworks and show success message
    setTimeout(() => {
      setCakeMsg(t.cakeSuccess);
      // Explode fireworks in background
      if (fireworksRef.current) {
        fireworksRef.current.launch();
      }
      // Trigger first floating wish!
      triggerFloatingWish();
    }, 800);
  };

  const handleLaunchFireworks = () => {
    if (fireworksRef.current) {
      fireworksRef.current.launch();
    }
  };

  const handleOpenLetter = () => {
    setLetterOpen(true);
    // Smooth scroll down to letter area
    setTimeout(() => {
      document.getElementById('letterCard')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }, 200);
  };

  return (
    <div className="relative w-full min-h-screen bg-[#FAF4E8] text-[#1A0A0F] font-serif overflow-x-hidden">
      
      {/* Falling Flower Petals & Sparkles continuous layer */}
      <FallingPetals />

      {/* Floating Audio Controller */}
      {unlocked && introComplete && (
        <div className="fixed top-6 right-6 z-50 flex items-center gap-3">
          {/* Music Play/Pause Button */}
          <button
            onClick={() => setMusicPlaying(!musicPlaying)}
            className={`flex items-center justify-center px-4 py-2 bg-rose-950/85 hover:bg-[#800020] hover:scale-110 border border-gold2/30 rounded-full cursor-pointer shadow-lg backdrop-blur-md transition-all duration-300 active:scale-95 gap-3 group ${
              !musicPlaying ? 'music-btn-muted opacity-80' : ''
            }`}
            title={musicPlaying ? t.musicBoxPlaying : t.musicBoxMuted}
          >
            <div className="music-wave">
              <span></span>
              <span></span>
              <span></span>
              <span></span>
              <span></span>
            </div>
            <span className="font-sans text-[10px] uppercase tracking-wider text-gold2 font-semibold select-none group-hover:text-white transition-colors">
              {musicPlaying ? 'Music ON' : 'Muted'}
            </span>
          </button>
        </div>
      )}

      {/* 1. App Entry Loader */}
      <AnimatePresence>
        {!appLoaded && (
          <motion.div
            key="app-loader"
            exit={{ opacity: 0, transition: { duration: 0.8 } }}
            className="fixed inset-0 z-[99999] flex flex-col items-center justify-center bg-black text-beige font-sans"
          >
            <motion.span
              animate={{ scale: [1, 1.25, 1] }}
              transition={{ repeat: Infinity, duration: 1.4 }}
              className="text-6xl mb-6"
            >
              🌹
            </motion.span>
            <h2 className="font-serif text-xl tracking-[0.2em] text-beige uppercase font-bold animate-pulse text-center px-4">
              Loading Love Story for LEONA
            </h2>
            <p className="text-[10px] tracking-[0.4em] text-gold uppercase mt-2 opacity-80">
              A journey through our forever
            </p>
            <div className="w-44 h-[1px] bg-rose-900/30 mt-8 relative overflow-hidden">
              <motion.div 
                animate={{ left: ['-100%', '100%'] }}
                transition={{ repeat: Infinity, duration: 1.8, ease: "easeInOut" }}
                className="absolute top-0 bottom-0 w-24 bg-gradient-to-r from-transparent via-gold to-transparent"
              />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 2. Security Lock Screen */}
      <AnimatePresence>
        {appLoaded && !unlocked && (
          <LockScreen 
            onUnlock={handleUnlock} 
            translations={t} 
          />
        )}
      </AnimatePresence>

      {/* 3. Cinematic 3D beating heart entry intro */}
      <AnimatePresence>
        {unlocked && !introComplete && (
          <CinematicIntro 
            onComplete={handleIntroComplete} 
            translations={t} 
          />
        )}
      </AnimatePresence>

      {/* 4. MAIN PAGE WRAPPER */}
      <AnimatePresence>
        {introComplete && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1 }}
            className="relative"
          >
            
            {/* 4a. BIRTH DAY CALENDAR */}
            <BirthCalendar translations={t} />

            {/* 4b. HERO HEADER SECTION */}
            <section id="hero" className="relative min-h-screen flex flex-col items-center justify-center py-24 px-6 bg-gradient-to-b from-[#FAF4E8] to-[#EFE0C0] text-center overflow-hidden">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 1 }}
                className="max-w-4xl"
              >
                <div className="flex justify-center items-center gap-1.5 mb-4 text-rose-950/20 text-xxs tracking-[0.4em] uppercase font-bold">
                  <span>✦</span><span>✿</span><span>✦</span>
                </div>

                <p className="font-sans text-[10px] sm:text-xs tracking-[0.45em] text-gold font-bold uppercase mb-4">
                  {t.heroEyebrow}
                </p>

                <h1 className="font-serif text-6xl sm:text-8xl md:text-[9.5rem] font-bold text-rose-900 leading-none tracking-tight drop-shadow-[0_4px_30px_rgba(139,32,53,0.15)] select-none">
                  LEONA
                </h1>

                <p className="font-serif text-sm sm:text-lg md:text-xl italic text-rose-950/75 mt-8 tracking-wider">
                  {t.heroTagline}
                </p>

                {/* Animated Typewriter container */}
                <div className="mt-8 min-h-[4rem] flex items-center justify-center font-serif text-lg sm:text-2xl text-rose-800 drop-shadow-[0_2px_10px_rgba(212,85,106,0.1)]">
                  <span className="font-semibold">{typewriterText}</span>
                  <span className="inline-block w-0.5 h-6 bg-rose-800 ml-1.5 animate-pulse" />
                </div>

                {/* Scrolling down pointer */}
                <div className="mt-16 flex flex-col items-center gap-2 opacity-80">
                  <span className="font-sans text-[9px] tracking-[0.4em] text-gold uppercase">
                    {t.scrollExplore}
                  </span>
                  <motion.div
                    animate={{ y: [0, 8, 0] }}
                    transition={{ repeat: Infinity, duration: 1.8, ease: "easeInOut" }}
                    className="w-5 h-8 border border-gold/40 rounded-full flex justify-center pt-1"
                  >
                    <ArrowDown className="w-3.5 h-3.5 text-gold" />
                  </motion.div>
                </div>

              </motion.div>
            </section>

            {/* 4c. LIVE COUNTDOWN SECTION */}
            <section id="countdown" className="relative bg-black py-24 px-6 text-center text-beige">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8 }}
                className="max-w-4xl mx-auto"
              >
                <p className="font-sans text-[10px] tracking-[0.35em] text-gold2 font-bold uppercase mb-2">
                  {t.countdownEyebrow}
                </p>
                <h2 className="font-serif text-3xl sm:text-5xl font-bold text-beige tracking-wide drop-shadow-[0_0_20px_rgba(232,201,122,0.25)] mb-12">
                  {t.countdownTitle}
                </h2>

                <div className="flex flex-wrap gap-4 sm:gap-6 justify-center items-center max-w-2xl mx-auto">
                  
                  {/* Days */}
                  <div className="flex-1 min-w-[100px] max-w-[130px] p-6 bg-amber-50/5 border border-gold/25 rounded-md backdrop-blur-md">
                    <span className="font-serif text-3xl sm:text-5xl font-bold text-gold2 block">
                      {countdown.days}
                    </span>
                    <span className="font-sans text-[10px] tracking-widest text-beige/55 uppercase mt-2 block">
                      {t.days}
                    </span>
                  </div>

                  {/* Hours */}
                  <div className="flex-1 min-w-[100px] max-w-[130px] p-6 bg-amber-50/5 border border-gold/25 rounded-md backdrop-blur-md">
                    <span className="font-serif text-3xl sm:text-5xl font-bold text-gold2 block">
                      {countdown.hours}
                    </span>
                    <span className="font-sans text-[10px] tracking-widest text-beige/55 uppercase mt-2 block">
                      {t.hours}
                    </span>
                  </div>

                  {/* Minutes */}
                  <div className="flex-1 min-w-[100px] max-w-[130px] p-6 bg-amber-50/5 border border-gold/25 rounded-md backdrop-blur-md">
                    <span className="font-serif text-3xl sm:text-5xl font-bold text-gold2 block">
                      {countdown.minutes}
                    </span>
                    <span className="font-sans text-[10px] tracking-widest text-beige/55 uppercase mt-2 block">
                      {t.minutes}
                    </span>
                  </div>

                  {/* Seconds */}
                  <div className="flex-1 min-w-[100px] max-w-[130px] p-6 bg-amber-50/5 border border-gold/25 rounded-md backdrop-blur-md">
                    <span className="font-serif text-3xl sm:text-5xl font-bold text-gold2 block">
                      {countdown.seconds}
                    </span>
                    <span className="font-sans text-[10px] tracking-widest text-beige/55 uppercase mt-2 block">
                      {t.seconds}
                    </span>
                  </div>

                </div>

                <p className="font-serif text-sm sm:text-lg italic text-beige/70 max-w-[500px] mx-auto mt-12 leading-relaxed">
                  {t.countdownMessage}
                </p>
              </motion.div>
            </section>

            {/* 4d. RELATIONSHIP MEMORIES TIMELINE (Scroll background slides) */}
            <section id="timeline" className="relative min-h-screen py-24 px-6 overflow-hidden bg-black">
              
              {/* Slideshow background linked to scroll index */}
              <div className="absolute inset-0 z-0">
                {gallerySlides.map((slide, idx) => (
                  <div
                    key={idx}
                    className="absolute inset-0 bg-cover bg-center transition-opacity duration-1000"
                    style={{
                      backgroundImage: `url('${slide.image}')`,
                      opacity: timelineBgIndex === idx ? 0.28 : 0
                    }}
                  />
                ))}
                {/* Fallback pattern just in case */}
                <div className="absolute inset-0 bg-gradient-to-b from-black via-rose-950/20 to-black z-0 pointer-events-none" />
              </div>

              {/* Velvet layer */}
              <div className="absolute inset-0 bg-gradient-to-b from-black/90 via-black/95 to-black/90 z-0 pointer-events-none" />

              <div className="relative z-10 max-w-4xl mx-auto">
                
                <div className="text-center mb-16">
                  <p className="font-sans text-[10px] tracking-[0.35em] text-gold2 font-bold uppercase mb-2">
                    {t.timelineEyebrow}
                  </p>
                  <h2 className="font-serif text-3xl sm:text-5xl font-bold text-beige tracking-wide drop-shadow-sm">
                    {t.timelineTitle}
                  </h2>
                  <div className="w-12 h-[1px] bg-gold2/40 mx-auto mt-4" />
                </div>

                {/* Core Timeline Structure */}
                <div className="relative border-l border-gradient border-gold/30 pl-8 ml-4 sm:ml-12 flex flex-col gap-12">
                  {timelineEvents.map((event, idx) => (
                    <motion.div
                      key={idx}
                      initial={{ opacity: 0, x: -30 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      viewport={{ once: true, margin: "-100px" }}
                      transition={{ duration: 0.8 }}
                      className="relative bg-[#1A0A0F]/65 border border-gold2/25 p-6 sm:p-8 rounded-lg shadow-2xl backdrop-blur-md max-w-xl"
                    >
                      {/* Pinned bullet */}
                      <span className="absolute left-[-42px] top-8 w-5 h-5 rounded-full bg-rose-900 border-2 border-gold flex items-center justify-center text-xxs shadow-md">
                        ✿
                      </span>

                      <div className="flex items-center gap-3.5 mb-4">
                        <span className="text-3xl select-none">{event.emoji}</span>
                        <div>
                          <p className="font-sans text-[9px] tracking-widest text-gold2 uppercase font-semibold">
                            {lang === 'en' ? event.dateEn : event.dateBn}
                          </p>
                          <h4 className="font-serif text-lg sm:text-xl font-bold text-beige mt-0.5">
                            {lang === 'en' ? event.titleEn : event.titleBn}
                          </h4>
                        </div>
                      </div>

                      <p className="font-serif italic text-sm text-beige/80 leading-relaxed">
                        {lang === 'en' ? event.textEn : event.textBn}
                      </p>
                    </motion.div>
                  ))}
                </div>

              </div>
            </section>

            {/* 4e. INTERACTIVE PHOTO GALLERY */}
            <section id="gallery" className="py-24 px-6 bg-black">
              <div className="max-w-6xl mx-auto">
                
                <div className="text-center mb-16">
                  <p className="font-sans text-[10px] tracking-[0.35em] text-gold2 font-bold uppercase mb-2">
                    {t.galleryEyebrow}
                  </p>
                  <h2 className="font-serif text-3xl sm:text-5xl font-bold text-beige tracking-wide drop-shadow-sm">
                    {t.galleryTitle}
                  </h2>
                  <div className="w-12 h-[1px] bg-gold2/40 mx-auto mt-4" />
                </div>

                {/* Slideshow element with descriptions */}
                <div className="relative max-w-xl mx-auto aspect-[4/3] rounded-lg overflow-hidden border border-gold/30 shadow-[0_20px_50px_rgba(107,26,42,0.3)] mb-16">
                  {gallerySlides.map((slide, idx) => (
                    <div
                      key={idx}
                      className="absolute inset-0 bg-cover bg-center transition-all duration-1000 flex flex-col justify-end p-6"
                      style={{
                        backgroundImage: `url('${slide.image}')`,
                        opacity: activeSlide === idx ? 1 : 0,
                        transform: activeSlide === idx ? 'scale(1)' : 'scale(1.05)'
                      }}
                    >
                      {/* Gradient overlay for readability */}
                      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/10 to-transparent pointer-events-none" />

                      <div className="relative z-10">
                        <span className="font-sans text-[8px] tracking-[0.3em] text-gold/60 uppercase block mb-1">
                          Memory {slide.num}
                        </span>
                        <p className="font-serif italic text-sm text-beige/90 leading-relaxed font-semibold">
                          {lang === 'en' ? slide.captionEn : slide.captionBn}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Responsive Photo Grid with click-to-lightbox */}
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3.5">
                  {gallerySlides.map((slide, idx) => (
                    <motion.div
                      key={idx}
                      initial={{ opacity: 0, scale: 0.9 }}
                      whileInView={{ opacity: 1, scale: 1 }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.6, delay: idx * 0.05 }}
                      whileHover={{ scale: 1.05, y: -4 }}
                      onClick={() => setLightboxImg(slide.image)}
                      className="group relative aspect-square rounded-md overflow-hidden border border-gold/10 hover:border-gold/35 shadow-md cursor-pointer"
                    >
                      <div
                        className="w-full h-full bg-cover bg-center filter grayscale-[30%] group-hover:grayscale-0 transition-all duration-500"
                        style={{ backgroundImage: `url('${slide.image}')` }}
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-3 pointer-events-none">
                        <p className="font-serif italic text-[9px] text-beige select-none truncate">
                          {lang === 'en' ? slide.captionEn : slide.captionBn}
                        </p>
                      </div>
                    </motion.div>
                  ))}
                </div>

              </div>
            </section>

            {/* 4f-0. OUR 6 SPECIAL MEMORIES TOGETHER */}
            <OurMoments />

            {/* 4f. POLAROID WALL (3D hover parallax tilt) */}
            <PolaroidWall 
              photos={polaroidPhotos} 
              translations={t} 
              lang={lang} 
            />

            {/* 4g. LOVE WORLD GLOBE & RESPONSE NOTES WALL */}
            <LoveWorld 
              initialNotes={initialNotes} 
              translations={t} 
              lang={lang} 
            />

            {/* 4g-2. INTERACTIVE TREASURE CHEST (Trivia, Promises, Reasons) */}
            <InteractiveTreasure />

            {/* 4h. SECRET LETTER ENVELOPE CARD */}
            <section id="letter" className="py-24 px-6 text-center bg-gradient-to-r from-rose-950 to-rose-900 text-beige">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="max-w-3xl mx-auto"
              >
                <p className="font-sans text-[10px] tracking-[0.35em] text-gold2/60 font-bold uppercase mb-2">
                  {t.letterEyebrow}
                </p>
                <h2 className="font-serif text-3xl sm:text-5xl font-bold text-gold2 tracking-wide drop-shadow-sm mb-8">
                  {t.letterTitle}
                </h2>

                {/* Sealed Envelope Graphic */}
                <AnimatePresence>
                  {!letterOpen && (
                    <motion.div
                      exit={{ scale: 0.8, opacity: 0, transition: { duration: 0.5 } }}
                      onClick={handleOpenLetter}
                      className="inline-flex flex-col items-center justify-center cursor-pointer group"
                    >
                      <motion.div
                        animate={{ y: [0, -8, 0] }}
                        transition={{ repeat: Infinity, duration: 2.2, ease: "easeInOut" }}
                        className="text-8xl select-none drop-shadow-[0_15px_30px_rgba(201,168,76,0.35)] hover:scale-110 transition-transform"
                      >
                        💌
                      </motion.div>
                      <button className="mt-8 px-8 py-3.5 border border-gold/45 hover:border-gold hover:bg-gold/5 text-gold2 tracking-[0.3em] font-sans font-bold text-xs uppercase cursor-pointer rounded-full transition-all">
                        {t.letterBtn}
                      </button>
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* Slide out paper letter card */}
                <AnimatePresence>
                  {letterOpen && (
                    <motion.div
                      id="letterCard"
                      initial={{ scale: 0.9, opacity: 0, y: 50 }}
                      animate={{ scale: 1, opacity: 1, y: 0 }}
                      transition={{ duration: 0.8, ease: "easeOut" }}
                      className="max-w-2xl mx-auto bg-[#FFF8EE] rounded-sm p-8 sm:p-12 border-t-4 border-rose-900 shadow-2xl text-[#1A0A0F] text-left relative"
                    >
                      {/* Decorative border ribbon */}
                      <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-rose-900 via-gold to-rose-900" />

                      <p className="font-serif text-xl sm:text-2xl italic font-bold text-rose-900 mb-6 drop-shadow-sm">
                        {t.letterGreeting}
                      </p>

                      <div className="font-serif text-base text-stone-800 leading-relaxed space-y-4 font-semibold italic">
                        {lang === 'en' ? (
                          <>
                            <p>There are not enough words in any language I know to describe what you mean to me. But today, on your birthday, I want to try.</p>
                            <p>You are the first thought that greets me every morning and the last warmth I carry into my dreams. You make ordinary moments feel like scenes from a movie I never want to end.</p>
                            <p>Your laugh is my favourite sound in the world. Your eyes hold a universe I could spend eternity exploring. Your kindness is the most beautiful thing I have ever witnessed.</p>
                            <p>I never knew what it meant to truly cherish someone — until you. You showed me what love looks like when it's patient, when it's gentle, when it's real.</p>
                            <p>Today is YOUR day, Leona. The world became a better place the moment you were born into it. And I became a better person the moment you walked into my life.</p>
                            <p>Happy Birthday, my love. May every wish your heart holds come true, starting with the ones you're too shy to say out loud.</p>
                            <p>I love you — yesterday, today, and in every tomorrow that comes.</p>
                          </>
                        ) : (
                          <>
                            <p>আমার জানা কোনো ভাষায় এমন যথেষ্ট শব্দ নেই যা দিয়ে বোঝাতে পারি তুমি আমার কাছে কী। তবে আজ, তোমার জন্মদিনে, আমি একটু চেষ্টা করতে চাই।</p>
                            <p>তুমি সেই প্রথম চিন্তা যা প্রতিদিন সকালে আমাকে জাগিয়ে তোলে এবং সেই শেষ উষ্ণতা যা আমি আমার স্বপ্নে বহন করি। তুমি সাধারণ মুহূর্তগুলোকে এমন সিনেমার মতো মনে করাও যার শেষ আমি কখনোই চাই না।</p>
                            <p>তোমার ওই মিষ্টি হাসি আমার পৃথিবীর সবচেয়ে প্রিয় শব্দ। তোমার চোখ দুটোতে যেন এক আস্ত মহাবিশ্ব লুকিয়ে আছে যা আমি অনন্তকাল ধরে অন্বেষণ করতে পারি। তোমার দয়া ও ভালোবাসা আমার দেখা সবচেয়ে সুন্দর জিনিস।</p>
                            <p>আমি কখনো জানতাম না কাউকে সত্যিই লালন করার মানে কী — যতক্ষণ না তুমি এসেছ। তুমি আমাকে দেখিয়েছ ভালোবাসা দেখতে কেমন হয় যখন এটি ধৈর্যশীল হয়, যখন এটি কোমল হয়, যখন এটি বাস্তব হয়।</p>
                            <p>আজ তোমার দিন, লিওনা। তুমি যেদিন এই পৃথিবীতে এসেছিলে সেদিন বিশ্ব এক অনন্য রূপ পেয়েছিল। আর তুমি যেদিন আমার জীবনে এসেছিলে সেদিন আমি এক নতুন জীবন পেয়েছিলাম।</p>
                            <p>শুভ জন্মদিন, আমার ভালোবাসা, আমার পাখি। তোমার মনের প্রতিটি ইচ্ছা যেন সত্য হয়, বিশেষ করে সেই ইচ্ছাগুলো যা তুমি সলজ্জে মনে মনে রাখো।</p>
                            <p>আমি তোমাকে ভালোবাসি — গতকাল, আজ এবং আসন্ন প্রতিটি আগামীতে।</p>
                          </>
                        )}
                      </div>

                      <div className="mt-12 text-right border-t border-rose-950/10 pt-6">
                        <p className="font-serif italic text-lg text-rose-900 font-bold leading-relaxed whitespace-pre-line">
                          {t.letterSign}
                        </p>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

              </motion.div>
            </section>

            {/* 4i. INTERACTIVE CANDLE BLOW CAKE */}
            <section id="cake" className="py-24 px-6 text-center bg-[#FFF8EE]">
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8 }}
                className="max-w-xl mx-auto"
              >
                <p className="font-sans text-[10px] tracking-[0.35em] text-gold font-bold uppercase mb-2">
                  {t.cakeEyebrow}
                </p>
                <h2 className="font-serif text-3xl sm:text-5xl font-bold text-rose-900 tracking-wide mb-12">
                  {t.cakeTitle}
                </h2>

                {/* Cake element with glowing flame */}
                <div 
                  onClick={handleBlowCandle}
                  className="relative inline-block cursor-pointer select-none group mb-8"
                >
                  {/* Flickering Flame overlay */}
                  <AnimatePresence>
                    {!candleBlown && (
                      <motion.div
                        animate={{ 
                          scale: [1, 1.15, 1, 1.2, 1],
                          x: [0, -1, 1, -0.5, 0]
                        }}
                        transition={{ repeat: Infinity, duration: 0.35 }}
                        exit={{ opacity: 0, scale: 0, transition: { duration: 0.4 } }}
                        className="absolute top-[-30px] left-1/2 -translate-x-1/2 w-8 h-10 bg-gradient-to-t from-amber-400 via-orange-500 to-transparent rounded-full filter blur-[1px] shadow-[0_0_20px_rgba(251,191,36,0.8)] pointer-events-none"
                      />
                    )}
                  </AnimatePresence>

                  <span className="text-8xl sm:text-9xl block transition-transform duration-500 group-hover:scale-110">
                    🎂
                  </span>
                </div>

                <div className="min-h-[3rem] mt-4">
                  <AnimatePresence mode="wait">
                    {candleBlown ? (
                      <motion.button
                        key="blown-state"
                        initial={{ scale: 0.9, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        className="px-8 py-3.5 bg-gradient-to-r from-green-700 to-green-850 border border-green-500/25 text-white tracking-widest font-sans font-bold text-xs uppercase rounded-md shadow-lg"
                      >
                        🕯️ Blown with Love 💖
                      </motion.button>
                    ) : (
                      <motion.button
                        key="active-state"
                        onClick={handleBlowCandle}
                        whileHover={{ y: -2 }}
                        className="px-8 py-3.5 bg-rose-900 hover:bg-rose-950 border border-gold/30 text-gold2 tracking-[0.3em] font-sans font-bold text-xs uppercase cursor-pointer rounded-md shadow-lg"
                      >
                        {t.cakeBtn}
                      </motion.button>
                    )}
                  </AnimatePresence>
                </div>

                <p className="font-serif italic text-sm text-rose-950/70 mt-6 leading-relaxed">
                  {cakeMsg || t.cakeInstruction}
                </p>

              </motion.div>
            </section>

            {/* 4j. 3D PARTICLE HEART CANVAS */}
            <ParticleHeart translations={t} />

            {/* 4k. FIREWORKS FINALE SECTION */}
            <section id="finale" className="relative min-h-screen flex flex-col items-center justify-center text-center bg-black text-beige py-24 px-6 overflow-hidden">
              
              {/* Full background Canvas fireworks */}
              <FireworksCanvas ref={fireworksRef} />

              <div className="finale-content relative z-10 max-w-3xl">
                <p className="font-sans text-[10px] tracking-[0.4em] text-gold2/60 uppercase font-semibold mb-4">
                  {lang === 'en' ? 'The end is just the beginning' : 'শেষের পরেই নতুন শুরু'}
                </p>

                <h1 className="font-serif text-5xl sm:text-7xl md:text-8xl font-bold text-beige leading-none tracking-tight drop-shadow-[0_4px_40px_rgba(201,168,76,0.35)] uppercase whitespace-pre-line">
                  {t.finaleTitle}
                </h1>

                <div className="text-3xl my-8 animate-pulse">
                  🌹 ❤️ 🌹
                </div>

                <p className="font-serif text-lg sm:text-2xl md:text-3xl italic text-gold2 font-medium tracking-wide">
                  {t.finaleSubtitle}
                </p>

                <p className="font-serif text-sm sm:text-lg italic text-beige/65 mt-8 tracking-wider">
                  {t.finaleSignature}
                </p>

                <button
                  onClick={handleLaunchFireworks}
                  className="mt-12 px-10 py-4 bg-rose-900/60 hover:bg-rose-900 border border-gold/40 hover:border-gold text-gold2 tracking-[0.35em] font-sans font-bold text-xs uppercase rounded-md backdrop-blur-md cursor-pointer transition-all active:scale-95 shadow-2xl"
                >
                  {t.celebrateBtn}
                </button>
              </div>
            </section>

          </motion.div>
        )}
      </AnimatePresence>

      {/* Lightbox Modal View for photos */}
      <AnimatePresence>
        {lightboxImg && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setLightboxImg(null)}
            className="fixed inset-0 z-[99999] bg-black/95 flex items-center justify-center p-4 cursor-zoom-out"
          >
            <motion.img
              initial={{ scale: 0.95 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.95 }}
              src={lightboxImg}
              alt="High Resolution Memory"
              className="max-w-full max-h-[90vh] object-contain rounded shadow-2xl border border-white/5"
            />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Floating extra birthday wishes toast notifications */}
      <div className="fixed bottom-6 right-6 z-[9999] flex flex-col gap-3 max-w-[340px] w-full pointer-events-none">
        <AnimatePresence>
          {floatingWishes.map((wish) => (
            <motion.div
              key={wish.id}
              initial={{ opacity: 0, x: 100, y: 20, scale: 0.9 }}
              animate={{ opacity: 1, x: 0, y: 0, scale: 1 }}
              exit={{ opacity: 0, x: 120, scale: 0.9, transition: { duration: 0.25 } }}
              className="pointer-events-auto bg-[#FCF8F2] border-2 border-amber-500/30 rounded-xl p-4 shadow-[0_12px_32px_rgba(139,32,53,0.18)] flex gap-3 items-start relative overflow-hidden"
            >
              {/* Sparkly left decorative edge */}
              <div className="absolute top-0 bottom-0 left-0 w-1 bg-gradient-to-b from-amber-400 via-rose-500 to-amber-500" />
              
              <div className="w-8 h-8 rounded-full bg-amber-100/80 flex items-center justify-center shrink-0">
                <Sparkles className="w-4 h-4 text-amber-600 fill-amber-500/10 animate-pulse" />
              </div>
              
              <div className="flex-1">
                <p className="font-sans text-[13px] font-medium text-stone-800 leading-relaxed">
                  {wish.text}
                </p>
                <p className="font-serif italic text-[11px] text-rose-950 font-semibold mt-1 leading-relaxed border-t border-amber-500/10 pt-1">
                  "{wish.textBn}"
                </p>
              </div>

              {/* Close Button */}
              <button
                onClick={() => setFloatingWishes((prev) => prev.filter((w) => w.id !== wish.id))}
                className="text-stone-400 hover:text-stone-600 text-xs shrink-0 cursor-pointer self-start p-0.5 hover:bg-stone-100 rounded-md transition-colors"
              >
                ✕
              </button>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Cursor tracking magic dust sparkle trail */}
      <MagicDust />

    </div>
  );
}
