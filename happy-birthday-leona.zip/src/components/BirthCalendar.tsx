import { motion } from 'motion/react';
import { Calendar, Award, Compass, Heart } from 'lucide-react';
import { TranslationSet } from '../types';

interface BirthCalendarProps {
  translations: TranslationSet;
}

export default function BirthCalendar({ translations }: BirthCalendarProps) {
  // Calendar data for July 2005
  // July 1, 2005 was a Friday. July has 31 days.
  const emptyCells = 5; // Friday index (0 = Sun, 1 = Mon... 5 = Fri)
  const totalDays = 31;
  const specialDay = 4; // July 4th

  const days: (number | null)[] = [
    ...Array(emptyCells).fill(null),
    ...Array.from({ length: totalDays }, (_, i) => i + 1)
  ];

  // Pictures in photo strip
  const stripPhotos = [
    { url: 'https://i.ibb.co.com/203s09Pd/IMG-1980.avif', tilt: '-3deg', caption: "Our Spring Day 🌸" },
    { url: 'https://i.ibb.co.com/BVZkYnGx/IMG-1986.avif', tilt: '2deg', caption: "Sweetest smile 💖" },
    { url: 'https://i.ibb.co.com/YFLktYHm/IMG-1440.avif', tilt: '-2deg', caption: "My peace 💫" }
  ];

  return (
    <section id="birthCalendar" className="relative min-h-screen py-24 px-6 overflow-hidden flex flex-col items-center justify-center bg-radial from-[#1e0710] to-[#0a0306]">
      {/* Dynamic drifting glow blobs */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute w-[450px] h-[450px] rounded-full blur-[90px] opacity-20 -top-20 -left-20 animate-pulse duration-[8000ms] bg-gradient-to-tr from-rose-900 to-amber-700" />
        <div className="absolute w-[450px] h-[450px] rounded-full blur-[90px] opacity-15 -bottom-20 -right-20 animate-pulse duration-[10000ms] bg-gradient-to-br from-purple-900 to-rose-700" />
      </div>

      {/* Sparks floating */}
      <div className="absolute inset-0 pointer-events-none z-10 flex justify-around items-center">
        <span className="absolute top-[12%] left-[6%] text-xl opacity-35 animate-bounce">✨</span>
        <span className="absolute top-[18%] right-[8%] text-2xl opacity-30 animate-pulse duration-[3000ms]">🌹</span>
        <span className="absolute bottom-[16%] left-[5%] text-lg opacity-40 animate-bounce duration-[4000ms]">💫</span>
        <span className="absolute bottom-[22%] right-[6%] text-xl opacity-25 animate-pulse">✨</span>
        <span className="absolute top-[48%] left-[2%] text-lg opacity-35 animate-bounce duration-[5000ms]">🌸</span>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-100px" }}
        transition={{ duration: 0.8 }}
        className="relative z-10 w-full max-w-5xl"
      >
        <div className="text-center mb-16">
          <p className="font-sans text-xs tracking-[0.35em] text-gold/90 uppercase font-semibold mb-2">
            {translations.dayTitle}
          </p>
          <div className="w-12 h-[1px] bg-gold/50 mx-auto" />
        </div>

        {/* Calendar and Photos Layout */}
        <div className="flex flex-col lg:flex-row items-center justify-center gap-12 lg:gap-20">
          
          {/* Month Calendar Card */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9, rotateY: 15 }}
            whileInView={{ opacity: 1, scale: 1, rotateY: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1, type: "spring" }}
            className="w-full max-w-[340px] bg-amber-50/95 rounded-xl overflow-hidden shadow-[0_30px_80px_rgba(0,0,0,0.65),0_0_0_1px_rgba(201,168,76,0.25)] border border-gold/15"
          >
            {/* Calendar Header with hangers */}
            <div className="relative bg-gradient-to-r from-rose-900 to-rose-950 px-6 py-6 text-center">
              {/* Paper binder spiral loops */}
              <div className="absolute -top-3.5 left-10 w-2.5 h-6 bg-gold/85 rounded-full shadow-md border border-amber-200/25" />
              <div className="absolute -top-3.5 right-10 w-2.5 h-6 bg-gold/85 rounded-full shadow-md border border-amber-200/25" />
              
              <h3 className="font-serif text-2xl font-bold text-beige tracking-widest uppercase">
                July
              </h3>
              <p className="font-sans text-xxs tracking-[0.3em] text-gold/80 mt-1 font-medium">
                2005
              </p>
            </div>

            {/* Grid Body */}
            <div className="p-6">
              {/* Weekdays */}
              <div className="grid grid-cols-7 mb-4 text-center">
                {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((day, idx) => (
                  <span key={idx} className="font-sans text-[10px] font-bold text-rose-950/45 uppercase tracking-wider">
                    {day}
                  </span>
                ))}
              </div>

              {/* Days */}
              <div className="grid grid-cols-7 row-gap-3.5 gap-y-3.5 text-center">
                {days.map((day, idx) => {
                  if (day === null) {
                    return <div key={`empty-${idx}`} />;
                  }
                  
                  const isSpecial = day === specialDay;
                  
                  return (
                    <div
                      key={`day-${day}`}
                      className={`relative font-serif text-xs font-semibold py-2 flex items-center justify-center rounded-full transition-all ${
                        isSpecial
                          ? 'text-white'
                          : 'text-rose-950/70 hover:bg-rose-950/10 cursor-pointer'
                      }`}
                    >
                      {isSpecial && (
                        <motion.div
                          animate={{ scale: [1, 1.15, 1] }}
                          transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
                          className="absolute inset-1 rounded-full bg-gradient-to-br from-rose-600 to-rose-900 shadow-[0_0_15px_rgba(212,85,106,0.85)] z-0"
                        />
                      )}
                      <span className="relative z-10">{day}</span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Footer */}
            <div className="px-6 pb-6 text-center">
              <div className="w-1/2 h-[1px] bg-gradient-to-r from-transparent via-gold to-transparent mx-auto mb-4" />
              <p className="font-serif text-[13px] italic text-rose-900 leading-relaxed font-medium">
                {translations.bornText}
              </p>
            </div>
          </motion.div>

          {/* Photo Strip beside calendar */}
          <div className="flex flex-row lg:flex-col gap-6 items-center">
            {stripPhotos.map((photo, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, x: 50, rotate: parseFloat(photo.tilt) }}
                whileInView={{ opacity: 1, x: 0, rotate: parseFloat(photo.tilt) }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: 0.2 + idx * 0.15 }}
                whileHover={{ scale: 1.08, rotate: 0, zIndex: 10 }}
                className="group relative w-24 h-24 sm:w-28 sm:h-28 md:w-32 md:h-32 bg-white rounded-lg p-2 shadow-[0_15px_40px_rgba(0,0,0,0.55),0_0_0_2px_rgba(255,255,255,0.9)] border border-amber-100/10 cursor-pointer"
              >
                <div
                  className="w-full h-full bg-cover bg-center rounded-md filter grayscale-[20%] group-hover:grayscale-0 transition-all duration-500"
                  style={{ backgroundImage: `url('${photo.url}')` }}
                />
                
                {/* Micro tooltip */}
                <span className="absolute left-1/2 -translate-x-1/2 bottom-[-10px] bg-rose-950 text-beige text-[8px] tracking-wider py-1 px-2.5 rounded-full opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap shadow-md pointer-events-none z-20">
                  {photo.caption}
                </span>
              </motion.div>
            ))}
          </div>

        </div>

        {/* Quote at the bottom */}
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 0.8 }}
          viewport={{ once: true }}
          transition={{ duration: 1, delay: 0.8 }}
          className="font-serif text-sm sm:text-base italic text-beige/65 text-center max-w-[480px] mx-auto mt-16 leading-relaxed"
        >
          {translations.calendarQuote}
        </motion.p>
      </motion.div>
    </section>
  );
}
