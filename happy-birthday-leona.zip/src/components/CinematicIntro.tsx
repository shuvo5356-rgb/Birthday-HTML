import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { TranslationSet } from '../types';

interface CinematicIntroProps {
  onComplete: () => void;
  translations: TranslationSet;
}

export default function CinematicIntro({ onComplete, translations }: CinematicIntroProps) {
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    // Auto complete after 6.5 seconds
    const timer = setTimeout(() => {
      handleSkip();
    }, 6500);

    return () => clearTimeout(timer);
  }, []);

  const handleSkip = () => {
    setVisible(false);
    setTimeout(() => {
      onComplete();
    }, 1200); // Wait for transition fade out
  };

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          id="cinemaIntro"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ 
            opacity: 0,
            transition: { duration: 1.2, ease: "easeOut" }
          }}
          className="fixed inset-0 z-[9999] flex flex-col items-center justify-center overflow-hidden bg-radial from-rose-950/90 to-black"
        >
          {/* Drifting gradient backdrop */}
          <div className="absolute inset-[-20%] pointer-events-none mix-blend-color-dodge opacity-20 blur-[100px] animate-pulse duration-[10000ms] bg-gradient-to-tr from-rose-700 via-pink-600 to-amber-500" />

          {/* Glowing particle ring */}
          <div className="absolute w-[300px] h-[300px] sm:w-[450px] sm:h-[450px] rounded-full border border-rose-500/10 animate-spin duration-[40000ms]" />
          <div className="absolute w-[290px] h-[290px] sm:w-[440px] sm:h-[440px] rounded-full border border-dashed border-gold/10 animate-spin duration-[25000ms] reverse" />

          {/* Big pulsing beating heart */}
          <motion.div
            animate={{
              scale: [1, 1.15, 1, 1.18, 1],
              rotateY: [0, 15, 0, -15, 0]
            }}
            transition={{
              repeat: Infinity,
              duration: 2.2,
              ease: "easeInOut"
            }}
            className="text-8xl sm:text-9xl md:text-[10rem] cursor-pointer drop-shadow-[0_0_80px_rgba(212,85,106,0.65)] select-none z-10"
            onClick={handleSkip}
          >
            ❤️
          </motion.div>

          {/* Giant movie style cinematic name title */}
          <motion.h2
            initial={{ opacity: 0, letterSpacing: '40px' }}
            animate={{ opacity: 1, letterSpacing: '16px' }}
            transition={{ delay: 1.2, duration: 2.5, ease: "easeOut" }}
            className="mt-12 font-serif text-5xl sm:text-7xl md:text-8xl font-extrabold text-beige text-center z-10 drop-shadow-[0_0_40px_rgba(232,201,122,0.45)] uppercase"
          >
            LEONA
          </motion.h2>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.6 }}
            transition={{ delay: 2.2, duration: 1.5 }}
            className="mt-4 font-sans text-xs tracking-[0.4em] text-gold uppercase text-center max-w-[280px]"
          >
            {translations.subtitle}
          </motion.p>

          {/* Interactive Tap Button */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 3.5, duration: 0.8 }}
            className="absolute bottom-12 font-sans text-xs tracking-widest text-gold2/60 uppercase cursor-pointer hover:text-gold transition-colors z-20 py-2 px-6 border border-gold2/10 hover:border-gold2/30 rounded-full"
            onClick={handleSkip}
          >
            {translations.skipIntro}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
