import { useEffect, useRef } from 'react';

export default function FallingPetals() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    // Particle types
    // 'rose' = red petal, 'lily' = white petal, 'sparkle' = gold sparkle, 'heart' = pink heart
    type ParticleType = 'rose' | 'lily' | 'sparkle' | 'heart';

    interface Petal {
      x: number;
      y: number;
      size: number;
      type: ParticleType;
      speedY: number;
      speedX: number;
      rotation: number;
      spinSpeed: number;
      opacity: number;
      symbol: string;
    }

    const symbols = {
      rose: '🌹',
      lily: '🪷',
      sparkle: '✨',
      heart: '💖'
    };

    const types: ParticleType[] = ['rose', 'lily', 'sparkle', 'heart'];
    const maxPetals = 45;
    const petals: Petal[] = [];

    const createPetal = (isInit = false): Petal => {
      const type = types[Math.floor(Math.random() * types.length)];
      return {
        x: Math.random() * width,
        y: isInit ? Math.random() * height : -20,
        size: Math.random() * 12 + 10,
        type,
        symbol: symbols[type],
        speedY: Math.random() * 1.5 + 0.8,
        speedX: (Math.random() - 0.5) * 1.0,
        rotation: Math.random() * Math.PI * 2,
        spinSpeed: (Math.random() - 0.5) * 0.03,
        opacity: Math.random() * 0.45 + 0.35
      };
    };

    // Initialize petals
    for (let i = 0; i < maxPetals; i++) {
      petals.push(createPetal(true));
    }

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', handleResize);

    const animate = () => {
      ctx.clearRect(0, 0, width, height);

      for (let i = 0; i < petals.length; i++) {
        const p = petals[i];
        p.y += p.speedY;
        p.x += p.speedX;
        p.rotation += p.spinSpeed;

        // Reset if goes off screen
        if (p.y > height + 20 || p.x < -20 || p.x > width + 20) {
          petals[i] = createPetal(false);
          continue;
        }

        ctx.save();
        ctx.globalAlpha = p.opacity;
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rotation);
        
        ctx.font = `${p.size}px sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(p.symbol, 0, 0);
        
        ctx.restore();
      }

      animationFrameId = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      id="fallingPetalsCanvas"
      className="fixed inset-0 pointer-events-none z-10"
    />
  );
}
