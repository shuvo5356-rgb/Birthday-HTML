import { useEffect, useRef, useImperativeHandle, forwardRef } from 'react';

export interface FireworksRef {
  launch: () => void;
}

const FireworksCanvas = forwardRef<FireworksRef, {}>((_, ref) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const particlesRef = useRef<any[]>([]);
  const launchesRef = useRef<number>(0);

  const colors = ['#C9A84C', '#6B1A2A', '#E8C97A', '#D4556A', '#FAF4E8', '#8B2035', '#FFD700', '#FF6B8A', '#22D3EE', '#F43F5E'];

  useImperativeHandle(ref, () => ({
    launch() {
      triggerShow();
    }
  }));

  const triggerShow = () => {
    launchesRef.current = 0;
    const canvas = canvasRef.current;
    if (!canvas) return;

    // Launch a series of auto bursts
    const autoLaunch = () => {
      if (launchesRef.current < 20) {
        const x = Math.random() * canvas.width;
        const y = Math.random() * canvas.height * 0.55 + 50;
        createBurst(x, y);
        launchesRef.current++;
        setTimeout(autoLaunch, 300 + Math.random() * 400);
      }
    };
    autoLaunch();
  };

  const createBurst = (x: number, y: number) => {
    const burstCount = 80;
    const list = particlesRef.current;

    for (let i = 0; i < burstCount; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 8 + 3;
      list.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - 1.5,
        alpha: 1,
        color: colors[Math.floor(Math.random() * colors.length)],
        radius: Math.random() * 2.5 + 1.5,
        decay: 0.012 + Math.random() * 0.015
      });
    }

    // Also throw some emoji hearts falling down from burst origin
    const shapes = ['❤️', '💕', '✨', '🌸', '💫'];
    for (let j = 0; j < 6; j++) {
      setTimeout(() => {
        const el = document.createElement('div');
        el.className = 'fixed text-xl pointer-events-none select-none z-50 animate-bounce duration-[4000ms]';
        el.textContent = shapes[Math.floor(Math.random() * shapes.length)];
        el.style.left = `${(x / (canvasRef.current?.width || window.innerWidth)) * window.innerWidth}px`;
        el.style.top = `${(y / (canvasRef.current?.height || window.innerHeight)) * window.innerHeight}px`;
        el.style.opacity = '1';
        el.style.transition = 'all 3.5s cubic-bezier(0.1, 0.8, 0.3, 1)';
        document.body.appendChild(el);

        // Animate down and fade out
        setTimeout(() => {
          el.style.transform = `translate(${(Math.random() - 0.5) * 100}px, 200px) scale(1.5)`;
          el.style.opacity = '0';
        }, 50);

        setTimeout(() => el.remove(), 3600);
      }, j * 100);
    }
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = (canvas.width = canvas.offsetWidth);
    let height = (canvas.height = canvas.offsetHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = canvas.offsetWidth;
      height = canvas.height = canvas.offsetHeight;
    };
    window.addEventListener('resize', handleResize);

    const handleCanvasClick = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      const clickX = e.clientX - rect.left;
      const clickY = e.clientY - rect.top;
      createBurst(clickX, clickY);
    };
    canvas.addEventListener('click', handleCanvasClick);

    let animationFrameId: number;

    const animate = () => {
      ctx.fillStyle = 'rgba(26, 10, 15, 0.15)';
      ctx.fillRect(0, 0, width, height);

      const list = particlesRef.current;
      for (let i = list.length - 1; i >= 0; i--) {
        const p = list[i];
        p.x += p.vx;
        p.y += p.vy;
        p.vy += 0.12; // Gravity pull down
        p.vx *= 0.98; // Drag friction
        p.alpha -= p.decay;

        if (p.alpha <= 0) {
          list.splice(i, 1);
          continue;
        }

        ctx.save();
        ctx.globalAlpha = p.alpha;
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }

      animationFrameId = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
      if (canvas) canvas.removeEventListener('click', handleCanvasClick);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      id="fireworksCanvas"
      className="absolute inset-0 w-full h-full pointer-events-auto cursor-crosshair z-0"
    />
  );
});

FireworksCanvas.displayName = 'FireworksCanvas';

export default FireworksCanvas;
