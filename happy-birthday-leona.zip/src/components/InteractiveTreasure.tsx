import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, Heart, Gift, BookOpen, CheckCircle2, Award, ArrowRight, RotateCcw, HelpCircle } from 'lucide-react';

interface Question {
  id: number;
  question: string;
  options: string[];
  correctIdx: number;
  explanation: string;
}

export default function InteractiveTreasure() {
  const [activeTab, setActiveTab] = useState<'promises' | 'trivia' | 'reasons' | 'gift'>('promises');
  const [giftOpened, setGiftOpened] = useState(false);

  // --- TRIVIA STATE ---
  const questions: Question[] = [
    {
      id: 1,
      question: "Where did our paths first cross, setting off this beautiful adventure?",
      options: [
        "Ome TV (A random swipe of destiny)",
        "On a busy street in July",
        "In a beautiful dream, before we even knew"
      ],
      correctIdx: 0,
      explanation: "Exactly! An ordinary swipe on Ome TV became the best second of my life! ❤️"
    },
    {
      id: 2,
      question: "What is Sadiq's absolute favorite thing about Leona (Pakhi)?",
      options: [
        "Her sweet laughter & voice",
        "Her soft, caring soul",
        "The way she overthinks because she cares",
        "All of the above, endlessly!"
      ],
      correctIdx: 3,
      explanation: "Yes! There's no single thing. It is absolutely everything about you, every single day! ❤️"
    },
    {
      id: 3,
      question: "What nickname makes Sadiq's heart beat faster than anything?",
      options: [
        "Pakhi",
        "Leona",
        "My Queen"
      ],
      correctIdx: 0,
      explanation: "Yes, Pakhi! You are my little bird, forever resting in my heart. 🕊️"
    },
    {
      id: 4,
      question: "My absolute favorite memory with you will always be...",
      options: [
        "Our first long conversation",
        "The day we finally met in person",
        "Every single second I spend with you"
      ],
      correctIdx: 1,
      explanation: "The first time we met in person was pure magic! Everything about that day was perfect — the sky, the air, and you standing right there. ❤️"
    }
  ];

  const [currentQ, setCurrentQ] = useState(0);
  const [selectedOpt, setSelectedOpt] = useState<number | null>(null);
  const [answered, setAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [quizFinished, setQuizFinished] = useState(false);

  const handleOptionClick = (idx: number) => {
    if (answered) return;
    setSelectedOpt(idx);
    setAnswered(true);
    if (idx === questions[currentQ].correctIdx) {
      setScore(score + 1);
    }
  };

  const handleNextQuestion = () => {
    setSelectedOpt(null);
    setAnswered(false);
    if (currentQ < questions.length - 1) {
      setCurrentQ(currentQ + 1);
    } else {
      setQuizFinished(true);
    }
  };

  const resetQuiz = () => {
    setCurrentQ(0);
    setSelectedOpt(null);
    setAnswered(false);
    setScore(0);
    setQuizFinished(false);
  };

  // --- PROMISES STATE ---
  const promises = [
    {
      title: "To Listen & Peace",
      desc: "I promise to always listen, even when you overthink, and hold your hand until your mind is completely at peace.",
      emoji: "🤝",
      color: "from-amber-50 to-orange-100"
    },
    {
      title: "To Create Magic",
      desc: "I promise to sing to you, read with you, and build our cozy dreamland where we can laugh without any worries.",
      emoji: "🎶",
      color: "from-rose-50 to-pink-100"
    },
    {
      title: "To Choose You Always",
      desc: "I promise to choose you, stand by you, and remind you of how beautiful you are on your darkest days.",
      emoji: "👑",
      color: "from-rose-50 to-amber-100"
    },
    {
      title: "To Cherish Every Detail",
      desc: "I promise to cherish every tiny detail of you — your smile, your soft laugh, your beautiful voice, and your soul.",
      emoji: "✨",
      color: "from-pink-50 to-rose-100"
    },
    {
      title: "To Be Your Safe Haven",
      desc: "I promise to be your comfort, your safest home, and your biggest cheerleader in everything you dream of doing.",
      emoji: "🏡",
      color: "from-orange-50 to-amber-100"
    },
    {
      title: "To Grow in Love",
      desc: "I promise to love you more tomorrow than I do today, and tomorrow, even more, with no end.",
      emoji: "🌱",
      color: "from-rose-50 to-orange-50"
    }
  ];
  const [openedPromiseIdx, setOpenedPromiseIdx] = useState<number | null>(null);

  // --- REASONS STATE ---
  const reasons = [
    {
      title: "Your Soft Heart",
      text: "You care so deeply about the people you love. Your empathy, soft care, and loving nature make the world a softer and brighter place.",
      icon: "❤️"
    },
    {
      title: "Your Giggle & Voice",
      text: "The sound of your sweet giggle is Sadiq's absolute favorite melody in the world. Hearing you talk calms my mind instantly.",
      icon: "🎵"
    },
    {
      title: "How Safely You Love Me",
      text: "You chose us and you stay. In a world full of temporary things, you are my solid anchor and my beautiful reality.",
      icon: "⚓"
    },
    {
      title: "Your Cozy Overthinking",
      text: "Even when your mind spins with overthinking, it only shows how deeply you feel and how much you care about everything. I love you for it.",
      icon: "💭"
    },
    {
      title: "Our Shared Silence",
      text: "With you, even quietness is beautiful. We can just be together, without saying a word, and it feels like the safest home.",
      icon: "🧸"
    }
  ];
  const [currentReasonIdx, setCurrentReasonIdx] = useState(0);

  return (
    <section id="interactive-treasure" className="relative py-24 px-6 bg-gradient-to-b from-[#FAF4E8] to-black overflow-hidden">
      
      {/* Decorative vectors */}
      <div className="absolute inset-0 pointer-events-none opacity-40">
        <div className="absolute top-1/4 left-10 w-72 h-72 rounded-full bg-rose-200/20 blur-3xl" />
        <div className="absolute bottom-1/4 right-10 w-80 h-80 rounded-full bg-amber-200/20 blur-3xl" />
      </div>

      <div className="relative z-10 max-w-4xl mx-auto">
        
        {/* Header */}
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-rose-950/10 border border-rose-950/15 rounded-full mb-3"
          >
            <Sparkles className="w-4 h-4 text-rose-800" />
            <span className="font-sans text-[10px] tracking-widest font-bold text-rose-900 uppercase">Interactive Love Box</span>
          </motion.div>
          
          <h2 className="font-serif text-3xl sm:text-5xl font-bold text-stone-900 tracking-tight leading-none">
            Our Interactive Treasure Chest
          </h2>
          <p className="font-serif italic text-stone-600/80 mt-4 text-base max-w-lg mx-auto">
            A little corner filled with playfulness, promises, and reasons why Sadiq is so deeply in love with you.
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex flex-wrap justify-center gap-1.5 sm:gap-3 p-1.5 bg-rose-950/5 border border-rose-950/10 rounded-xl max-w-lg mx-auto mb-12 backdrop-blur-sm">
          <button
            onClick={() => setActiveTab('promises')}
            className={`flex-1 min-w-[80px] py-2.5 px-2 rounded-lg font-sans text-xxs sm:text-xs font-bold tracking-widest uppercase transition-all duration-300 cursor-pointer ${
              activeTab === 'promises'
                ? 'bg-rose-950 text-gold2 shadow-md'
                : 'text-stone-600 hover:bg-rose-950/10'
            }`}
          >
            🌸 Promises
          </button>
          
          <button
            onClick={() => setActiveTab('trivia')}
            className={`flex-1 min-w-[85px] py-2.5 px-2 rounded-lg font-sans text-xxs sm:text-xs font-bold tracking-widest uppercase transition-all duration-300 cursor-pointer ${
              activeTab === 'trivia'
                ? 'bg-rose-950 text-gold2 shadow-md'
                : 'text-stone-600 hover:bg-rose-950/10'
            }`}
          >
            🧩 Quiz
          </button>

          <button
            onClick={() => setActiveTab('reasons')}
            className={`flex-1 min-w-[80px] py-2.5 px-2 rounded-lg font-sans text-xxs sm:text-xs font-bold tracking-widest uppercase transition-all duration-300 cursor-pointer ${
              activeTab === 'reasons'
                ? 'bg-rose-950 text-gold2 shadow-md'
                : 'text-stone-600 hover:bg-rose-950/10'
            }`}
          >
            ❤️ Reasons
          </button>

          <button
            onClick={() => setActiveTab('gift')}
            className={`flex-1 min-w-[90px] py-2.5 px-2 rounded-lg font-sans text-xxs sm:text-xs font-bold tracking-widest uppercase transition-all duration-300 cursor-pointer ${
              activeTab === 'gift'
                ? 'bg-rose-950 text-gold2 shadow-md'
                : 'text-stone-600 hover:bg-rose-950/10'
            }`}
          >
            🎁 Gift
          </button>
        </div>

        {/* Tab content area */}
        <div className="min-h-[420px] flex items-center justify-center">
          <AnimatePresence mode="wait">
            
            {/* 1. PROMISES TAB */}
            {activeTab === 'promises' && (
              <motion.div
                key="promises"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                className="w-full text-center"
              >
                <p className="font-serif italic text-sm text-stone-600 mb-8 max-w-md mx-auto">
                  Click on any promise card to reveal Sadiq's heartfelt commitment to you.
                </p>

                <div className="grid grid-cols-2 md:grid-cols-3 gap-4 sm:gap-6">
                  {promises.map((p, idx) => (
                    <motion.div
                      key={idx}
                      whileHover={{ scale: 1.03, y: -4 }}
                      whileTap={{ scale: 0.97 }}
                      onClick={() => setOpenedPromiseIdx(idx)}
                      className="aspect-[4/3] sm:aspect-square flex flex-col items-center justify-center p-4 bg-white/70 border border-rose-900/10 rounded-xl cursor-pointer shadow-sm hover:shadow-md hover:border-rose-900/20 transition-all relative overflow-hidden group"
                    >
                      <span className="text-3xl mb-2 sm:mb-3 group-hover:scale-125 transition-transform duration-300">
                        {p.emoji}
                      </span>
                      <h4 className="font-sans text-[10px] sm:text-xs font-bold uppercase tracking-widest text-stone-800 text-center">
                        {p.title}
                      </h4>
                      <p className="text-[9px] sm:text-[10px] text-rose-800 font-semibold mt-1">
                        Reveal Promise →
                      </p>
                      
                      {/* Decorative border */}
                      <div className="absolute inset-1 border border-dashed border-rose-950/5 rounded-lg pointer-events-none" />
                    </motion.div>
                  ))}
                </div>

                {/* Promise Modal Overlay */}
                <AnimatePresence>
                  {openedPromiseIdx !== null && (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      onClick={() => setOpenedPromiseIdx(null)}
                      className="fixed inset-0 bg-black/75 flex items-center justify-center z-50 p-4 backdrop-blur-sm"
                    >
                      <motion.div
                        initial={{ scale: 0.9, y: 20 }}
                        animate={{ scale: 1, y: 0 }}
                        exit={{ scale: 0.9, y: 20 }}
                        onClick={(e) => e.stopPropagation()}
                        className={`max-w-md w-full bg-gradient-to-br ${promises[openedPromiseIdx].color} p-8 rounded-2xl border border-rose-200 shadow-2xl text-center relative overflow-hidden`}
                      >
                        {/* Sparkly corner overlays */}
                        <div className="absolute top-0 left-0 p-3 text-lg opacity-40">✨</div>
                        <div className="absolute bottom-0 right-0 p-3 text-lg opacity-40">✨</div>

                        <span className="text-5xl block mb-4 animate-bounce">
                          {promises[openedPromiseIdx].emoji}
                        </span>
                        
                        <p className="font-sans text-[10px] tracking-widest font-bold text-rose-800 uppercase mb-2">
                          My Forever Promise
                        </p>
                        
                        <h3 className="font-serif text-2xl font-bold text-stone-900 mb-4">
                          {promises[openedPromiseIdx].title}
                        </h3>
                        
                        <p className="font-serif italic text-base sm:text-lg text-stone-800 leading-relaxed font-medium mb-6">
                          "{promises[openedPromiseIdx].desc}"
                        </p>

                        <button
                          onClick={() => setOpenedPromiseIdx(null)}
                          className="px-6 py-2.5 bg-rose-950 hover:bg-rose-900 text-gold2 text-xs font-sans font-bold tracking-widest uppercase rounded-lg cursor-pointer shadow transition-all active:scale-95"
                        >
                          Keep close in heart ❤️
                        </button>
                      </motion.div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            )}

            {/* 2. TRIVIA QUIZ TAB */}
            {activeTab === 'trivia' && (
              <motion.div
                key="trivia"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                className="w-full max-w-xl mx-auto bg-white/80 border border-rose-950/10 rounded-2xl p-6 sm:p-8 shadow-md relative"
              >
                {!quizFinished ? (
                  <div>
                    {/* Progress Bar */}
                    <div className="w-full bg-rose-950/5 h-1 rounded-full overflow-hidden mb-6">
                      <div 
                        className="bg-rose-900 h-full transition-all duration-300"
                        style={{ width: `${((currentQ + 1) / questions.length) * 100}%` }}
                      />
                    </div>

                    <div className="flex items-center justify-between mb-4">
                      <span className="font-sans text-[10px] font-bold uppercase tracking-wider text-rose-800">
                        Question {currentQ + 1} of {questions.length}
                      </span>
                      <span className="font-sans text-[10px] font-bold uppercase tracking-wider text-amber-600">
                        Score: {score}
                      </span>
                    </div>

                    <h3 className="font-serif text-xl sm:text-2xl font-bold text-stone-900 mb-6 leading-snug">
                      {questions[currentQ].question}
                    </h3>

                    <div className="space-y-3 mb-6">
                      {questions[currentQ].options.map((opt, idx) => {
                        let btnStyle = "bg-stone-50 border-stone-200 hover:bg-rose-50 hover:border-rose-300 text-stone-800";
                        if (answered) {
                          if (idx === questions[currentQ].correctIdx) {
                            btnStyle = "bg-green-50 border-green-400 text-green-900 font-semibold";
                          } else if (idx === selectedOpt) {
                            btnStyle = "bg-red-50 border-red-400 text-red-950 opacity-80";
                          } else {
                            btnStyle = "bg-stone-50 border-stone-100 text-stone-400 opacity-60 pointer-events-none";
                          }
                        }

                        return (
                          <button
                            key={idx}
                            disabled={answered}
                            onClick={() => handleOptionClick(idx)}
                            className={`w-full text-left p-4 rounded-xl border text-xs sm:text-sm transition-all duration-300 cursor-pointer flex items-center justify-between group ${btnStyle}`}
                          >
                            <span className="pr-4">{opt}</span>
                            {answered && idx === questions[currentQ].correctIdx && (
                              <CheckCircle2 className="w-4 h-4 text-green-600 shrink-0" />
                            )}
                          </button>
                        );
                      })}
                    </div>

                    {/* Explanation & Next button */}
                    <AnimatePresence>
                      {answered && (
                        <motion.div
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="bg-rose-950/5 border border-rose-950/10 rounded-xl p-4 mb-6 text-left"
                        >
                          <p className="font-serif italic text-xs text-rose-950 leading-relaxed">
                            {questions[currentQ].explanation}
                          </p>
                        </motion.div>
                      )}
                    </AnimatePresence>

                    {answered && (
                      <motion.button
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        onClick={handleNextQuestion}
                        className="w-full py-3.5 bg-rose-950 hover:bg-rose-900 text-gold2 font-sans font-bold text-xs tracking-widest uppercase rounded-xl flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-95 shadow-md"
                      >
                        <span>{currentQ < questions.length - 1 ? "Next Question" : "See Results"}</span>
                        <ArrowRight className="w-4 h-4 text-gold2" />
                      </motion.button>
                    )}
                  </div>
                ) : (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="text-center py-6"
                  >
                    <div className="w-16 h-16 bg-amber-50 rounded-full flex items-center justify-center mx-auto mb-4 border border-gold2/30 shadow-inner">
                      <Award className="w-8 h-8 text-gold" />
                    </div>

                    <h3 className="font-serif text-2xl font-bold text-stone-900 mb-2">
                      Trivia Completed!
                    </h3>
                    
                    <p className="font-serif italic text-stone-600 text-sm mb-6 max-w-sm mx-auto">
                      You scored {score} out of {questions.length}! But truth is, you've already won Sadiq's entire heart forever, Leona. ❤️
                    </p>

                    <button
                      onClick={resetQuiz}
                      className="px-6 py-3 bg-rose-950 hover:bg-rose-900 text-gold2 text-xs font-sans font-bold tracking-widest uppercase rounded-lg flex items-center justify-center gap-2 mx-auto cursor-pointer transition-all active:scale-95 shadow"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Play Again</span>
                    </button>
                  </motion.div>
                )}
              </motion.div>
            )}

            {/* 3. REASONS DECK TAB */}
            {activeTab === 'reasons' && (
              <motion.div
                key="reasons"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                className="w-full max-w-md mx-auto"
              >
                <p className="font-serif italic text-sm text-stone-600 mb-8 text-center">
                  Cycle through these letters to know why you are the best thing that ever happened to me.
                </p>

                <div className="relative aspect-[4/3] w-full flex items-center justify-center mb-8">
                  <AnimatePresence mode="wait">
                    <motion.div
                      key={currentReasonIdx}
                      initial={{ opacity: 0, rotate: -4, scale: 0.95 }}
                      animate={{ opacity: 1, rotate: 2, scale: 1 }}
                      exit={{ opacity: 0, rotate: 4, scale: 0.95 }}
                      transition={{ duration: 0.3 }}
                      className="absolute inset-0 bg-stone-50 p-6 sm:p-8 rounded-xl border border-rose-950/15 shadow-[0_15px_35px_rgba(0,0,0,0.15)] flex flex-col justify-between"
                    >
                      {/* Decorative stamp/heart */}
                      <div className="absolute top-4 right-4 text-3xl select-none opacity-20">🌸</div>
                      <div className="absolute top-4 left-4 text-3xl select-none">
                        {reasons[currentReasonIdx].icon}
                      </div>

                      <div className="mt-6 text-left">
                        <span className="font-sans text-[9px] font-bold text-amber-600 uppercase tracking-widest block mb-1">
                          Reason #{currentReasonIdx + 1}
                        </span>
                        <h3 className="font-serif text-xl sm:text-2xl font-bold text-stone-900 mb-3">
                          {reasons[currentReasonIdx].title}
                        </h3>
                        <p className="font-serif italic text-xs sm:text-sm text-stone-700 leading-relaxed font-medium">
                          "{reasons[currentReasonIdx].text}"
                        </p>
                      </div>

                      <div className="flex items-center justify-between border-t border-rose-950/5 pt-4 mt-4">
                        <span className="text-[10px] font-sans font-bold tracking-widest text-rose-950">
                          FOR LEONA
                        </span>
                        <span className="text-[10px] font-sans font-bold tracking-widest text-rose-900/60">
                          BY SADIQ
                        </span>
                      </div>
                    </motion.div>
                  </AnimatePresence>
                </div>

                {/* Navigation indicators */}
                <div className="flex justify-between items-center px-2">
                  <button
                    disabled={currentReasonIdx === 0}
                    onClick={() => setCurrentReasonIdx(currentReasonIdx - 1)}
                    className="p-2 text-stone-500 hover:text-stone-800 disabled:opacity-30 disabled:pointer-events-none text-xs font-sans font-bold tracking-wider uppercase cursor-pointer"
                  >
                    ← Back
                  </button>

                  <div className="flex gap-1.5">
                    {reasons.map((_, idx) => (
                      <div 
                        key={idx}
                        onClick={() => setCurrentReasonIdx(idx)}
                        className={`w-1.5 h-1.5 rounded-full cursor-pointer transition-all duration-300 ${
                          idx === currentReasonIdx ? 'bg-rose-950 w-3' : 'bg-rose-950/20'
                        }`}
                      />
                    ))}
                  </div>

                  <button
                    disabled={currentReasonIdx === reasons.length - 1}
                    onClick={() => setCurrentReasonIdx(currentReasonIdx + 1)}
                    className="p-2 text-stone-500 hover:text-stone-800 disabled:opacity-30 disabled:pointer-events-none text-xs font-sans font-bold tracking-wider uppercase cursor-pointer"
                  >
                    Next →
                  </button>
                </div>
              </motion.div>
            )}

            {/* 4. DIGITAL GIFT TAB */}
            {activeTab === 'gift' && (
              <motion.div
                key="gift"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                className="w-full text-center max-w-lg mx-auto"
              >
                <p className="font-serif italic text-sm text-stone-600 mb-8 px-4">
                  Sadiq left a special virtual gift box here for you, Leona. Tap to unwrap it!
                </p>

                <div className="relative min-h-[360px] flex flex-col items-center justify-center">
                  
                  {/* Outer container with box body and lid */}
                  <div className="relative w-64 h-64 flex items-center justify-center">
                    
                    <AnimatePresence mode="wait">
                      {!giftOpened ? (
                        <motion.div
                          key="closed-gift"
                          initial={{ opacity: 0, scale: 0.9 }}
                          animate={{ opacity: 1, scale: 1 }}
                          exit={{ opacity: 0, scale: 0.9 }}
                          className="relative flex flex-col items-center justify-center cursor-pointer"
                          onClick={() => setGiftOpened(true)}
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                        >
                          {/* Glowing background halo */}
                          <div className="absolute -inset-4 bg-rose-500/10 rounded-full blur-2xl animate-pulse" />

                          {/* Gift Lid */}
                          <div className="w-48 h-12 bg-gradient-to-r from-rose-750 via-rose-600 to-rose-800 rounded-sm relative z-30 shadow-lg border border-rose-500/15">
                            {/* Horizontal Gold Ribbon */}
                            <div className="absolute inset-0 flex items-center">
                              <div className="w-full h-3.5 bg-gradient-to-r from-amber-500 via-amber-300 to-amber-600 shadow-inner" />
                            </div>
                            
                            {/* Vertical Gold Ribbon segment */}
                            <div className="absolute top-0 bottom-0 left-1/2 -translate-x-1/2 w-8 bg-gradient-to-b from-amber-400 via-amber-300 to-amber-500 shadow-inner" />

                            {/* Bow Ties */}
                            <div className="absolute -top-5 left-1/2 -translate-x-1/2 flex gap-1 z-40">
                              <div className="w-10 h-7 rounded-full border-[3.5px] border-amber-300 bg-amber-400 -rotate-45 transform origin-right shadow-md" />
                              <div className="w-10 h-7 rounded-full border-[3.5px] border-amber-300 bg-amber-400 rotate-45 transform origin-left shadow-md" />
                            </div>
                          </div>

                          {/* Gift Box Body */}
                          <div className="w-44 h-40 bg-gradient-to-b from-rose-800 via-rose-900 to-rose-950 rounded-b-lg relative z-20 shadow-2xl border-x border-b border-rose-950/40 -mt-1 overflow-hidden">
                            {/* Vertical Gold Ribbon */}
                            <div className="absolute top-0 bottom-0 left-1/2 -translate-x-1/2 w-8 bg-gradient-to-b from-amber-400 via-amber-300 to-amber-500 shadow-inner" />
                            
                            {/* Shimmer light effect across the box */}
                            <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/5 to-transparent animate-pulse" />
                          </div>

                          <span className="font-sans text-[11px] font-bold text-rose-800 uppercase tracking-widest mt-6 animate-bounce">
                            Tap to Open 🎁
                          </span>
                        </motion.div>
                      ) : (
                        <motion.div
                          key="opened-gift"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          exit={{ opacity: 0 }}
                          className="relative flex flex-col items-center justify-center w-full"
                        >
                          {/* Confetti / Hearts Burst Animation elements */}
                          <div className="absolute inset-0 pointer-events-none overflow-visible z-50">
                            {[...Array(14)].map((_, i) => (
                              <motion.div
                                key={i}
                                initial={{ 
                                  opacity: 1, 
                                  scale: 0, 
                                  x: 0, 
                                  y: 40 
                                }}
                                animate={{ 
                                  opacity: [0, 1, 1, 0], 
                                  scale: [0.5, 1.4, 1.1, 0.6], 
                                  x: (Math.random() - 0.5) * 260, 
                                  y: -140 - Math.random() * 120,
                                  rotate: Math.random() * 360
                                }}
                                transition={{ duration: 1.8, ease: "easeOut", delay: i * 0.04 }}
                                className="absolute text-xl left-1/2 top-1/2"
                              >
                                {i % 4 === 0 ? '💖' : i % 4 === 1 ? '✨' : i % 4 === 2 ? '🌸' : '🎈'}
                              </motion.div>
                            ))}
                          </div>

                          {/* Empty Box Base sitting quietly */}
                          <motion.div
                            initial={{ y: 20, scale: 0.9, opacity: 0 }}
                            animate={{ y: 50, scale: 0.9, opacity: 0.25 }}
                            className="w-44 h-40 bg-gradient-to-b from-rose-800 via-rose-900 to-rose-950 rounded-b-lg relative z-10 shadow-lg border-x border-b border-rose-900/30 pointer-events-none"
                          >
                            <div className="absolute top-0 bottom-0 left-1/2 -translate-x-1/2 w-8 bg-gradient-to-b from-amber-400 via-amber-300 to-amber-500" />
                          </motion.div>

                          {/* Personalized Heart-shaped Gift Tag with Message */}
                          <motion.div
                            initial={{ scale: 0.3, y: 150, rotate: -15, opacity: 0 }}
                            animate={{ scale: 1, y: -70, rotate: 0, opacity: 1 }}
                            transition={{ type: "spring", damping: 16, stiffness: 90, delay: 0.15 }}
                            className="absolute z-40 max-w-sm w-full bg-[#FCF8F2] p-5 sm:p-6 rounded-2xl shadow-[0_20px_50px_rgba(139,32,53,0.35)] border-2 border-amber-500/40 text-center"
                          >
                            {/* Inner Crimson Border */}
                            <div className="absolute inset-1.5 border border-dashed border-rose-900/10 rounded-xl pointer-events-none" />

                            {/* Floating Heart Icon at the Top */}
                            <div className="flex justify-center -mt-12 mb-4">
                              <div className="w-14 h-14 bg-gradient-to-tr from-rose-600 to-pink-500 rounded-full flex items-center justify-center shadow-lg border-2 border-white animate-pulse">
                                <Heart className="w-7 h-7 text-white fill-white" />
                              </div>
                            </div>

                            <span className="font-sans text-[9px] font-bold tracking-[0.25em] text-rose-800 uppercase block mb-1">
                              Leona's Special Gift
                            </span>

                            <h4 className="font-serif text-lg font-bold text-stone-900 mb-3 leading-tight">
                              Happy Birthday, my sweet Pakhi! 🌸
                            </h4>

                            <div className="w-12 h-[1px] bg-amber-500/30 mx-auto mb-3" />

                            <div className="space-y-3.5 max-h-[220px] overflow-y-auto pr-1">
                              <p className="font-serif italic text-xs sm:text-sm text-stone-800 leading-relaxed font-medium px-1">
                                "You are my most precious gift, Leona. On this special day, my heart wishes you endless laughter, peace, and the cozy joy you bring to my life. I promise to love you, cherish your sweet giggle, and keep you safe forever."
                              </p>
                              
                              <p className="font-serif italic text-xs sm:text-sm text-rose-950 font-semibold leading-relaxed px-1">
                                "প্রিয় লিওনা, তুমি আমার জীবনের সবচেয়ে সুন্দর উপহার। তোমার এই বিশেষ দিনে আমার মন জুড়ে শুধু তোমার হাসি আর সুখের প্রার্থনা। সারাজীবন তোমার হাতটি ধরে ভালোবাসার বন্ধনে জড়িয়ে রাখতে চাই।"
                              </p>
                            </div>

                            <div className="w-12 h-[1px] bg-amber-500/30 mx-auto mt-3.5 mb-2.5" />

                            <span className="font-sans text-[10px] tracking-widest font-bold text-rose-850 uppercase block">
                              — Forever Yours, Sadiq ❤️
                            </span>

                            {/* Reset button to let her close and open again */}
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setGiftOpened(false);
                              }}
                              className="mt-5 font-sans text-[9px] font-bold text-amber-600 hover:text-amber-700 tracking-wider uppercase transition-colors"
                            >
                              Wrap It Back 🎁
                            </button>
                          </motion.div>

                        </motion.div>
                      )}
                    </AnimatePresence>

                  </div>

                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

      </div>
    </section>
  );
}
