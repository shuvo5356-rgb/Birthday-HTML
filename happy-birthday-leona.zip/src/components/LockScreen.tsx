import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Lock, Heart, Sparkles, HelpCircle } from 'lucide-react';
import { TranslationSet } from '../types';

interface LockScreenProps {
  onUnlock: () => void;
  translations: TranslationSet;
}

export default function LockScreen({ onUnlock, translations }: LockScreenProps) {
  const [inputValue, setInputValue] = useState('');
  const [isError, setIsError] = useState(false);
  const [isUnlocking, setIsUnlocking] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const normalizedVal = inputValue.trim().toUpperCase();
    
    // Support "LEONA" in English and "লিওনা" in Bengali
    if (normalizedVal === 'LEONA' || normalizedVal === 'লিওনা' || normalizedVal === 'LIONA') {
      setIsUnlocking(true);
      setTimeout(() => {
        onUnlock();
      }, 1000);
    } else {
      setIsError(true);
      setInputValue('');
      setTimeout(() => {
        setIsError(false);
      }, 2000);
    }
  };

  return (
    <AnimatePresence>
      {!isUnlocking && (
        <motion.div
          id="lockscreen"
          initial={{ opacity: 1 }}
          exit={{ 
            opacity: 0,
            scale: 1.1,
            filter: 'blur(10px)',
            transition: { duration: 1.2, ease: "easeInOut" }
          }}
          className="fixed inset-0 z-[9998] flex flex-col items-center justify-center overflow-hidden"
          style={{
            background: 'radial-gradient(ellipse at center, #2A0A14 0%, #1A0A0F 70%)'
          }}
        >
          {/* Animated background stars */}
          <div className="absolute inset-0 pointer-events-none opacity-30">
            <span className="absolute text-xl top-[10%] left-[12%] animate-pulse">🌹</span>
            <span className="absolute text-2xl top-[25%] right-[15%] animate-bounce duration-[4000ms]">✨</span>
            <span className="absolute text-lg bottom-[20%] left-[18%] animate-pulse duration-[3000ms]">💖</span>
            <span className="absolute text-xl bottom-[30%] right-[10%] animate-bounce duration-[5000ms]">🌸</span>
            <span className="absolute text-2xl top-[45%] left-[8%] animate-ping duration-[6000ms]">💫</span>
          </div>

          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.8 }}
            className="w-full max-w-md px-6 text-center z-10"
          >
            <motion.div
              animate={{ y: [0, -10, 0] }}
              transition={{ repeat: Infinity, duration: 3, ease: "easeInOut" }}
              className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-rose-900/40 border border-gold/30 mb-8 shadow-[0_0_30px_rgba(139,32,53,0.3)] text-gold"
            >
              <Lock className="w-8 h-8" />
            </motion.div>

            <h1 className="font-serif text-4xl sm:text-5xl font-bold text-beige tracking-widest uppercase mb-2 drop-shadow-[0_0_20px_rgba(212,85,106,0.5)]">
              LEONA
            </h1>
            
            <p className="font-sans text-xs tracking-[0.25em] text-gold/80 uppercase mb-12">
              {translations.enterWorld}
            </p>

            <form onSubmit={handleSubmit} className="relative max-w-xs mx-auto mb-6">
              <div className="relative flex items-center">
                <input
                  type="text"
                  id="lockInput"
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  placeholder={translations.lockInputPlaceholder}
                  autoComplete="off"
                  maxLength={15}
                  disabled={isUnlocking}
                  className={`w-full bg-rose-950/15 border text-center font-sans py-3.5 pl-6 pr-14 text-beige text-base tracking-[0.2em] rounded-md outline-none transition-all duration-400 ${
                    isError 
                      ? 'border-red-500 shadow-[0_0_20px_rgba(239,68,68,0.25)]' 
                      : 'border-gold/40 focus:border-gold focus:shadow-[0_0_25px_rgba(201,168,76,0.25)]'
                  }`}
                />
                <button
                  type="submit"
                  id="unlockBtn"
                  className="absolute right-4 text-gold hover:text-gold2 hover:scale-115 transition-all cursor-pointer"
                >
                  <Heart className="w-6 h-6 fill-gold/10 hover:fill-gold" />
                </button>
              </div>
            </form>

            {/* Hint & Errors */}
            <div className="min-h-[40px] flex flex-col items-center justify-center">
              <AnimatePresence mode="wait">
                {isError ? (
                  <motion.p
                    key="error"
                    initial={{ opacity: 0, y: -5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    className="text-red-400 font-sans text-xs tracking-wider font-medium"
                  >
                    {translations.lockError}
                  </motion.p>
                ) : (
                  <motion.div
                    key="hint"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 0.65 }}
                    className="flex items-center gap-1.5 text-gold/70 text-xs font-serif italic tracking-widest"
                  >
                    <HelpCircle className="w-3.5 h-3.5" />
                    <span>{translations.lockHint}</span>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
