import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Pin, ArrowRight, Sparkles, Heart } from 'lucide-react';
import { LoveNote, TranslationSet } from '../types';

interface LoveWorldProps {
  initialNotes: LoveNote[];
  translations: TranslationSet;
  lang: 'en' | 'bn';
}

export default function LoveWorld({ initialNotes, translations, lang }: LoveWorldProps) {
  const [notes, setNotes] = useState<LoveNote[]>(initialNotes);
  const [newNoteText, setNewNoteText] = useState('');

  const handleAddNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNoteText.trim()) return;

    const newNote: LoveNote = {
      id: Date.now().toString(),
      text: newNoteText.trim(),
      author: 'Leona',
      tilt: (Math.random() - 0.5) * 5 // Random tilt angle between -2.5 and 2.5
    };

    setNotes([...notes, newNote]);
    setNewNoteText('');
  };

  return (
    <section id="loveWorld" className="relative py-24 px-6 overflow-hidden text-center bg-gradient-to-b from-black via-[#0d040e] to-[#25030f]">
      
      {/* Background soft water lilies/hearts falling */}
      <div className="absolute inset-0 pointer-events-none z-0">
        <span className="absolute text-2xl opacity-40 top-10 left-[4%] animate-pulse">🤍</span>
        <span className="absolute text-xl opacity-30 top-[22%] right-[5%] animate-pulse duration-[3000ms]">🌸</span>
        <span className="absolute text-2xl opacity-40 top-[45%] left-[-2%] animate-pulse duration-[4000ms]">🤍</span>
        <span className="absolute text-xl opacity-35 top-[60%] right-[-1%] animate-pulse">🪷</span>
        <span className="absolute text-2xl opacity-40 bottom-12 left-[8%] animate-pulse duration-[5000ms]">🤍</span>
        <span className="absolute text-2xl opacity-35 bottom-4 right-[10%] animate-pulse duration-[2500ms]">🌸</span>
      </div>

      <div className="relative z-10 max-w-6xl mx-auto">
        
        <div className="text-center mb-12">
          <p className="font-sans text-[10px] tracking-[0.35em] text-gold2 font-bold uppercase mb-2">
            {translations.loveWorldEyebrow}
          </p>
          <h2 className="font-serif text-3xl sm:text-5xl font-bold text-beige tracking-wide drop-shadow-[0_0_30px_rgba(212,85,106,0.3)]">
            {translations.loveWorldTitle}
          </h2>
          <div className="w-12 h-[1px] bg-gold2/40 mx-auto mt-4" />
        </div>

        <p className="font-serif italic text-base text-beige/65 max-w-[500px] mx-auto mb-16 leading-relaxed">
          {translations.loveWorldIntro}
        </p>

        {/* Spinning Earth Globe Graphic */}
        <div className="flex flex-col items-center justify-center mb-16 relative">
          <div className="absolute w-[220px] h-[220px] bg-radial from-rose-900/35 to-transparent blur-[30px] rounded-full animate-pulse duration-[5000ms]" />
          
          <div className="relative w-36 h-36 flex items-center justify-center">
            {/* Orbits */}
            <div className="absolute inset-[-10px] rounded-full border border-gold/15 animate-spin duration-[15000ms]" />
            <div className="absolute inset-[-25px] rounded-full border border-dashed border-rose-500/15 animate-spin duration-[25000ms] reverse" />
            <div className="absolute inset-[-40px] rounded-full border border-gold/10 animate-spin duration-[35000ms]" />
            
            {/* Spinning Emoji Globe */}
            <motion.span
              animate={{ rotate: 360 }}
              transition={{ repeat: Infinity, duration: 24, ease: "linear" }}
              className="text-8xl select-none drop-shadow-[0_0_35px_rgba(212,85,106,0.55)] cursor-pointer"
            >
              🌍
            </motion.span>
          </div>

          <div className="mt-8 flex flex-col items-center gap-1.5 opacity-60 animate-bounce duration-[2000ms]">
            <Heart className="w-5 h-5 text-gold2 fill-gold2/10" />
            <ArrowRight className="w-4 h-4 text-gold2 rotate-90" />
          </div>
        </div>

        {/* Note Wall Board */}
        <div className="notes-wall bg-amber-50/5 p-6 sm:p-10 rounded-xl border border-gold/20 shadow-[0_20px_50px_rgba(0,0,0,0.45),inset_0_1px_0_rgba(255,255,255,0.04)] backdrop-blur-md mb-12">
          
          {/* Grid layout of pinned sticky notes */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            <AnimatePresence mode="popLayout">
              {notes.map((note) => {
                const isBySadiq = note.author.toLowerCase() === 'sadiq';
                
                return (
                  <motion.div
                    key={note.id}
                    initial={{ opacity: 0, scale: 0.8, y: 30 }}
                    whileInView={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.8, y: -30 }}
                    viewport={{ once: true }}
                    whileHover={{ scale: 1.05, zIndex: 20 }}
                    className={`relative p-5 text-left rounded-sm shadow-[0_10px_25px_rgba(0,0,0,0.35)] transition-shadow duration-300 ${
                      isBySadiq 
                        ? 'bg-amber-50/95 text-stone-900 border border-amber-100/40' 
                        : 'bg-rose-50/95 text-rose-950 border border-rose-100/40'
                    }`}
                    style={{
                      transform: `rotate(${note.tilt}deg)`,
                    }}
                  >
                    {/* Metal Pin Head */}
                    <span className="absolute -top-3.5 left-1/2 -translate-x-1/2 text-lg z-10 filter drop-shadow-[0_2px_4px_rgba(0,0,0,0.25)] select-none">
                      📌
                    </span>

                    <p className="font-serif italic text-sm leading-relaxed font-semibold pr-1">
                      {note.text}
                    </p>

                    <div className="mt-4 flex items-center justify-between">
                      <div className="w-6 h-[1px] bg-gold/50" />
                      <span className="font-sans text-[9px] font-bold tracking-widest text-gold uppercase">
                        — {note.author}
                      </span>
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        </div>

        {/* Input box for Leona to write response note */}
        <motion.form
          onSubmit={handleAddNote}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-md mx-auto relative flex items-center justify-center p-1 bg-rose-950/20 border border-gold/35 rounded-md focus-within:border-gold/80 transition-all duration-300"
        >
          <input
            type="text"
            value={newNoteText}
            onChange={(e) => setNewNoteText(e.target.value)}
            placeholder={translations.noteWallAddPlaceholder}
            maxLength={120}
            className="w-full bg-transparent border-none text-beige font-serif italic text-sm py-2.5 px-4 outline-none placeholder-beige/40 tracking-wider"
          />
          <button
            type="submit"
            className="mr-2 flex items-center gap-1.5 px-4 py-2 bg-gradient-to-r from-rose-900 to-rose-950 hover:from-rose-800 hover:to-rose-900 border border-gold/30 hover:border-gold text-gold2 text-[10px] font-sans font-bold tracking-widest uppercase rounded cursor-pointer transition-all active:scale-95"
          >
            <Pin className="w-3 h-3" />
            <span>{translations.noteWallAddBtn}</span>
          </button>
        </motion.form>

      </div>
    </section>
  );
}
