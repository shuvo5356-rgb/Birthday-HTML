import { useEffect, useRef } from 'react';

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  alpha: number;
  color: string;
  rotation: number;
  rotationSpeed: number;
  decay: number;
  type: 'star' | 'circle' | 'spark';
}

export default function MagicDust() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const pointerRef = useRef({ x: -1000, y: -1000, lastX: -1000, lastY: -1000 });
  const activeRef = useRef(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let particles: Particle[] = [];

    // Aesthetic romantic color palette
    const colors = [
      'rgba(232, 201, 122, 1)',  // Warm gold
      'rgba(245, 158, 11, 1)',   // Amber
      'rgba(244, 63, 94, 1)',    // Rose pink
      'rgba(255, 255, 255, 1)',  // Glistening white
      'rgba(251, 113, 133, 1)',  // Soft pink
    ];

    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    // Create a particle
    const createParticle = (x: number, y: number) => {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 1.5 + 0.5;
      
      const typeRand = Math.random();
      let type: 'star' | 'circle' | 'spark' = 'circle';
      if (typeRand < 0.3) {
        type = 'star';
      } else if (typeRand < 0.6) {
        type = 'spark';
      }

      const p: Particle = {
        x,
        y,
        vx: Math.cos(angle) * speed + (Math.random() - 0.5) * 0.4,
        vy: Math.sin(angle) * speed - 0.5, // subtle rising motion
        size: Math.random() * 4 + 2,
        alpha: 1.0,
        color: colors[Math.floor(Math.random() * colors.length)],
        rotation: Math.random() * Math.PI * 2,
        rotationSpeed: (Math.random() - 0.5) * 0.15,
        decay: Math.random() * 0.015 + 0.012, // fades out smoothly
        type
      };
      particles.push(p);
    };

    // Draw 4-pointed star
    const drawStar = (c: CanvasRenderingContext2D, cx: number, cy: number, spikes: number, outerRadius: number, innerRadius: number) => {
      let rot = Math.PI / 2 * 3;
      let x = cx;
      let y = cy;
      const step = Math.PI / spikes;

      c.beginPath();
      c.moveTo(cx, cy - outerRadius);
      for (let i = 0; i < spikes; i++) {
        x = cx + Math.cos(rot) * outerRadius;
        y = cy + Math.sin(rot) * outerRadius;
        c.lineTo(x, y);
        rot += step;

        x = cx + Math.cos(rot) * innerRadius;
        y = cy + Math.sin(rot) * innerRadius;
        c.lineTo(x, y);
        rot += step;
      }
      c.lineTo(cx, cy - outerRadius);
      c.closePath();
      c.fill();
    };

    const handleMouseMove = (e: MouseEvent) => {
      activeRef.current = true;
      pointerRef.current.lastX = pointerRef.current.x;
      pointerRef.current.lastY = pointerRef.current.y;
      pointerRef.current.x = e.clientX;
      pointerRef.current.y = e.clientY;

      // Only create particles if we moved a minimum distance, or randomly
      const dist = Math.hypot(pointerRef.current.x - pointerRef.current.lastX, pointerRef.current.y - pointerRef.current.lastY);
      if (dist > 3) {
        // Generate a few particles along the path for smooth density
        const steps = Math.min(Math.floor(dist / 5), 4) || 1;
        for (let i = 0; i < steps; i++) {
          const ratio = i / steps;
          const px = pointerRef.current.lastX + (pointerRef.current.x - pointerRef.current.lastX) * ratio;
          const py = pointerRef.current.lastY + (pointerRef.current.y - pointerRef.current.lastY) * ratio;
          createParticle(px, py);
        }
      }
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (e.touches.length === 0) return;
      activeRef.current = true;
      const touch = e.touches[0];
      pointerRef.current.lastX = pointerRef.current.x;
      pointerRef.current.lastY = pointerRef.current.y;
      pointerRef.current.x = touch.clientX;
      pointerRef.current.y = touch.clientY;

      const dist = Math.hypot(pointerRef.current.x - pointerRef.current.lastX, pointerRef.current.y - pointerRef.current.lastY);
      if (dist > 3) {
        const steps = Math.min(Math.floor(dist / 6), 3) || 1;
        for (let i = 0; i < steps; i++) {
          const ratio = i / steps;
          const px = pointerRef.current.lastX + (pointerRef.current.x - pointerRef.current.lastX) * ratio;
          const py = pointerRef.current.lastY + (pointerRef.current.y - pointerRef.current.lastY) * ratio;
          createParticle(px, py);
        }
      }
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('touchmove', handleTouchMove);

    // Physics update and render loop
    const tick = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];
        p.x += p.vx;
        p.y += p.vy;
        p.vy += 0.01; // tiny downward gravity drift
        p.alpha -= p.decay;
        p.rotation += p.rotationSpeed;

        if (p.alpha <= 0) {
          particles.splice(i, 1);
          continue;
        }

        ctx.save();
        ctx.globalAlpha = p.alpha;
        ctx.fillStyle = p.color;
        
        // Soft glowing filter on individual sparkles
        ctx.shadowBlur = p.size * 2;
        ctx.shadowColor = p.color;

        if (p.type === 'star') {
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rotation);
          drawStar(ctx, 0, 0, 4, p.size, p.size / 3.5);
        } else if (p.type === 'spark') {
          // elegant thin diamond spark
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rotation);
          ctx.beginPath();
          ctx.moveTo(0, -p.size * 1.5);
          ctx.lineTo(p.size * 0.4, 0);
          ctx.lineTo(0, p.size * 1.5);
          ctx.lineTo(-p.size * 0.4, 0);
          ctx.closePath();
          ctx.fill();
        } else {
          // simple perfect soft circle dust
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size / 2, 0, Math.PI * 2);
          ctx.fill();
        }

        ctx.restore();
      }

      // If active and mouse stays still, randomly generate subtle sparkles around the cursor
      if (activeRef.current && Math.random() < 0.12 && pointerRef.current.x > -500) {
        createParticle(
          pointerRef.current.x + (Math.random() - 0.5) * 16,
          pointerRef.current.y + (Math.random() - 0.5) * 16
        );
      }

      animationFrameId = requestAnimationFrame(tick);
    };

    tick();

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('touchmove', handleTouchMove);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none z-[999999]"
      style={{ mixBlendMode: 'screen' }}
    />
  );
}
