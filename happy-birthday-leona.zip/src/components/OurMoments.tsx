import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Heart, Sparkles } from 'lucide-react';

const images = [
  'https://i.ibb.co.com/203s09Pd/IMG-1980.avif',
  'https://i.ibb.co.com/BVZkYnGx/IMG-1986.avif',
  'https://i.ibb.co.com/YFLktYHm/IMG-1440.avif',
  'https://i.ibb.co.com/G3JjFNGj/IMG-1005.avif',
  'https://i.ibb.co.com/XR8r2xh/422d8301-96db-42e3-92ac-074ca56bb782.jpg',
  'https://i.ibb.co.com/1fYXSf03/IMG-1002.avif'
];

export default function OurMoments() {
  const [selectedImg, setSelectedImg] = useState<string | null>(null);

  return (
    <section id="our-moments" className="relative py-24 px-6 overflow-hidden bg-gradient-to-b from-[#1b0611] via-[#0d0107] to-[#070004] text-beige">
      
      {/* Soft atmospheric background lights */}
      <div className="absolute inset-0 pointer-events-none z-0">
        <div className="absolute top-1/3 left-1/4 w-80 h-80 bg-rose-950/20 rounded-full filter blur-[100px]" />
        <div className="absolute bottom-1/3 right-1/4 w-96 h-96 bg-amber-950/15 rounded-full filter blur-[120px]" />
      </div>

      <div className="relative z-10 max-w-6xl mx-auto">
        
        {/* Minimalist divider instead of text */}
        <div className="flex flex-col items-center justify-center mb-16 gap-3">
          <motion.div 
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="flex items-center gap-4"
          >
            <div className="w-16 sm:w-28 h-[1px] bg-gradient-to-r from-transparent via-amber-500/50 to-transparent" />
            <div className="relative flex items-center justify-center w-10 h-10 rounded-full bg-rose-950/30 border border-amber-500/30">
              <Heart className="w-5 h-5 text-amber-400 fill-amber-400/20 animate-pulse" />
              <Sparkles className="absolute -top-1 -right-1 w-3 h-3 text-amber-300" />
            </div>
            <div className="w-16 sm:w-28 h-[1px] bg-gradient-to-r from-transparent via-amber-500/50 to-transparent" />
          </motion.div>
        </div>

        {/* Art Gallery Wall of Luxurious Beveled Golden Frames */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-10 sm:gap-12 md:gap-14 justify-items-center">
          {images.map((url, idx) => {
            // Subtle alternating tilt values for an authentic gallery layout
            const rotation = idx % 3 === 0 ? '-1.5deg' : idx % 3 === 1 ? '1.5deg' : '0deg';

            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-40px" }}
                transition={{ duration: 0.8, delay: idx * 0.1 }}
                whileHover={{ 
                  scale: 1.03, 
                  rotate: '0deg',
                  zIndex: 30,
                  boxShadow: "0 30px 60px -15px rgba(0, 0, 0, 0.95), 0 0 20px 2px rgba(245, 158, 11, 0.15)"
                }}
                style={{ rotate: rotation }}
                className="group relative cursor-pointer transition-all duration-500 ease-out max-w-[320px] w-full"
                onClick={() => setSelectedImg(url)}
              >
                {/* 
                  ROYAL GOLDEN PORTRAIT FRAME SYSTEM
                  - Multi-layered bevel borders simulating carved gold and dark wood matting
                */}
                <div className="relative p-3 rounded-sm bg-gradient-to-br from-amber-700 via-amber-200 to-amber-800 shadow-[0_20px_45px_rgba(0,0,0,0.85),inset_0_1.5px_3px_rgba(255,255,255,0.45),inset_0_-1.5px_3px_rgba(0,0,0,0.6)]">
                  
                  {/* Innermost dark gap bevel to give physical 3D depth */}
                  <div className="p-[3px] bg-amber-950 rounded-sm">
                    
                    {/* Textured Matting (the board around the photo) */}
                    <div className="p-4 bg-gradient-to-b from-[#180610] to-[#0a0005] border border-amber-600/20 rounded-sm flex items-center justify-center">
                      
                      {/* Inner gold slip/fillet lining */}
                      <div className="relative p-[2px] bg-gradient-to-tr from-amber-500 via-amber-300 to-amber-600 rounded-sm overflow-hidden shadow-inner w-full">
                        
                        {/* The Portrait Image */}
                        <div className="relative aspect-[3/4] overflow-hidden bg-stone-900 w-full rounded-sm">
                          <div
                            className="w-full h-full bg-cover bg-center transition-transform duration-700 ease-out group-hover:scale-108"
                            style={{ backgroundImage: `url('${url}')` }}
                          />
                          
                          {/* Elegant light sweep overlay on hover */}
                          <div className="absolute inset-0 bg-rose-950/10 group-hover:bg-transparent transition-colors duration-500" />
                          
                          {/* Shimmer glaze bar */}
                          <div className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-white/5 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000 ease-out" />
                        </div>

                      </div>

                    </div>

                  </div>

                  {/* Corner ornate accents */}
                  <div className="absolute top-4 left-4 w-1.5 h-1.5 border-t border-l border-amber-400/40 rounded-tl-[1px] pointer-events-none" />
                  <div className="absolute top-4 right-4 w-1.5 h-1.5 border-t border-r border-amber-400/40 rounded-tr-[1px] pointer-events-none" />
                  <div className="absolute bottom-4 left-4 w-1.5 h-1.5 border-b border-l border-amber-400/40 rounded-bl-[1px] pointer-events-none" />
                  <div className="absolute bottom-4 right-4 w-1.5 h-1.5 border-b border-r border-amber-400/40 rounded-br-[1px] pointer-events-none" />
                </div>

                {/* Subtle drop light indicator below each luxury frame */}
                <div className="absolute -bottom-1 left-1/10 right-1/10 h-[1px] bg-amber-500/10 blur-[1px] opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              </motion.div>
            );
          })}
        </div>

        {/* Elegant bottom divider to close the gallery section */}
        <div className="flex justify-center mt-20">
          <div className="w-24 h-[1px] bg-gradient-to-r from-transparent via-amber-500/20 to-transparent" />
        </div>

      </div>

      {/* Lightbox for full-size viewing (No captions/text) */}
      <AnimatePresence>
        {selectedImg && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setSelectedImg(null)}
            className="fixed inset-0 z-[99999] bg-black/98 flex items-center justify-center p-4 cursor-zoom-out"
          >
            {/* Close button */}
            <motion.button
              className="absolute top-6 right-6 text-white/70 hover:text-white bg-white/5 hover:bg-white/10 rounded-full w-12 h-12 flex items-center justify-center text-xl font-light transition-all"
              onClick={() => setSelectedImg(null)}
            >
              ✕
            </motion.button>

            {/* Framed Lightbox View */}
            <motion.div
              initial={{ scale: 0.95 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.95 }}
              className="relative p-2.5 rounded bg-gradient-to-tr from-amber-600 via-amber-300 to-amber-700 shadow-2xl max-w-full max-h-[90vh]"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="p-1 bg-amber-950 rounded-[1px]">
                <img
                  src={selectedImg}
                  alt="High Resolution Framed Portrait"
                  className="max-w-[92vw] max-h-[82vh] object-contain rounded-[1px]"
                />
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </section>
  );
}
