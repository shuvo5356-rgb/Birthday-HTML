import { useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { TranslationSet } from '../types';

interface ParticleHeartProps {
  translations: TranslationSet;
}

export default function ParticleHeart({ translations }: ParticleHeartProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    let width = (canvas.width = canvas.offsetWidth * dpr);
    let height = (canvas.height = canvas.offsetHeight * dpr);

    // Heart parametric formula
    const heartShape = (t: number) => {
      const x = 16 * Math.pow(Math.sin(t), 3);
      const y = -(13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t));
      return [x, y];
    };

    const isMobile = window.innerWidth < 640;
    const particleCount = isMobile ? 650 : 1400;
    const colors = ['#C9A84C', '#E8C97A', '#D4556A', '#8B2035', '#FAF4E8', '#FFD37A'];
    
    interface Particle {
      baseX: number;
      baseY: number;
      x: number;
      y: number;
      size: number;
      color: string;
      speed: number;
      angleOffset: number;
    }

    let particles: Particle[] = [];
    let frame = 0;
    let assembled = false;
    const scale = (isMobile ? 8 : 12) * dpr;

    const makeParticles = () => {
      particles = [];
      for (let i = 0; i < particleCount; i++) {
        const t = Math.random() * Math.PI * 2;
        const [hx, hy] = heartShape(t);
        const jitter = 0.85 + Math.random() * 0.3;
        particles.push({
          baseX: hx * jitter,
          baseY: hy * jitter,
          x: (Math.random() - 0.5) * width + width / 2,
          y: (Math.random() - 0.5) * height + height / 2,
          size: (isMobile ? 0.8 : 1) + Math.random() * 1.8,
          color: colors[Math.floor(Math.random() * colors.length)],
          speed: 0.02 + Math.random() * 0.03,
          angleOffset: Math.random() * Math.PI * 2
        });
      }
    };

    makeParticles();

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = canvas.offsetWidth * dpr;
      height = canvas.height = canvas.offsetHeight * dpr;
      makeParticles();
      frame = 0;
      assembled = false;
    };
    window.addEventListener('resize', handleResize);

    let animationFrameId: number;

    const animate = () => {
      frame++;
      ctx.fillStyle = 'rgba(26, 10, 15, 0.18)';
      ctx.fillRect(0, 0, width, height);

      // Heart pulse breathing multiplier
      const pulse = 1 + Math.sin(frame * 0.045) * 0.045;
      const cx = width / 2;
      const cy = height / 2;

      particles.forEach((p) => {
        const targetX = cx + p.baseX * scale * pulse;
        const targetY = cy + p.baseY * scale * pulse;

        if (!assembled) {
          p.x += (targetX - p.x) * p.speed;
          p.y += (targetY - p.y) * p.speed;
        } else {
          // Slow floating drift once assembled
          const driftX = Math.sin(frame * 0.02 + p.angleOffset) * 1.5;
          const driftY = Math.cos(frame * 0.02 + p.angleOffset) * 1.5;
          p.x += (targetX + driftX - p.x) * 0.08;
          p.y += (targetY + driftY - p.y) * 0.08;
        }

        ctx.beginPath();
        ctx.fillStyle = p.color;
        
        // Glow shadows (only on desktops for performance)
        if (!isMobile) {
          ctx.shadowColor = p.color;
          ctx.shadowBlur = 4;
        }
        
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
      });

      if (!assembled && frame > 90) {
        assembled = true;
      }

      animationFrameId = requestAnimationFrame(animate);
    };

    // Begin loop
    animate();

    // Reset and trigger whenever scrolled into view
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            frame = 0;
            assembled = false;
            particles.forEach((p) => {
              p.x = (Math.random() - 0.5) * width + width / 2;
              p.y = (Math.random() - 0.5) * height + height / 2;
            });
          }
        });
      },
      { threshold: 0.25 }
    );

    const targetSection = document.getElementById('particleHeartSection');
    if (targetSection) observer.observe(targetSection);

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
      if (targetSection) observer.unobserve(targetSection);
    };
  }, []);

  return (
    <section 
      id="particleHeartSection" 
      className="relative bg-black py-24 px-6 min-h-screen flex flex-col items-center justify-center overflow-hidden"
    >
      <div className="relative z-10 text-center mb-6 max-w-lg">
        <p className="font-sans text-[10px] tracking-[0.35em] text-gold2 font-bold uppercase mb-2">
          {translations.particleHeartEyebrow}
        </p>
        <h2 className="font-serif text-3xl sm:text-5xl font-bold text-beige tracking-wide drop-shadow-[0_0_30px_rgba(212,85,106,0.35)] mb-4">
          {translations.particleHeartTitle}
        </h2>
        <div className="w-12 h-[1px] bg-gold2/40 mx-auto" />
      </div>

      {/* Render Canvas */}
      <canvas 
        ref={canvasRef} 
        className="w-full max-w-3xl h-[45vh] sm:h-[55vh] rounded-xl border border-stone-900 shadow-[0_0_50px_rgba(107,26,42,0.15)] bg-[#1a0a0f]" 
      />

      <p className="relative z-10 font-serif italic text-sm text-beige/55 text-center max-w-[480px] mt-8 leading-relaxed px-4">
        {translations.particleHeartDesc}
      </p>
    </section>
  );
}
