import React, { useRef } from 'react';
import { motion } from 'motion/react';
import { PolaroidPhoto, TranslationSet } from '../types';

interface PolaroidWallProps {
  photos: PolaroidPhoto[];
  translations: TranslationSet;
  lang: 'en' | 'bn';
}

export default function PolaroidWall({ photos, translations, lang }: PolaroidWallProps) {
  return (
    <section id="polaroid" className="py-24 px-6 bg-gradient-to-b from-[#FAF4E8] to-[#EFE0C0] overflow-hidden">
      <div className="max-w-6xl mx-auto">
        
        <div className="text-center mb-16">
          <p className="font-sans text-[10px] tracking-[0.35em] text-gold font-bold uppercase mb-2">
            {translations.polaroidEyebrow}
          </p>
          <h2 className="font-serif text-3xl sm:text-5xl font-bold text-rose-950 tracking-wide drop-shadow-sm">
            {translations.polaroidTitle}
          </h2>
          <div className="w-12 h-[1px] bg-gold/50 mx-auto mt-4" />
        </div>

        {/* Polaroid grid container */}
        <div className="flex flex-wrap gap-8 justify-center items-center">
          {photos.map((item, idx) => (
            <PolaroidCard key={idx} item={item} idx={idx} lang={lang} />
          ))}
        </div>

      </div>
    </section>
  );
}

// Sub-component to manage mouse moving 3D parallax on individual polaroids
function PolaroidCard({ item, idx, lang }: { item: PolaroidPhoto; idx: number; lang: 'en' | 'bn'; key?: any }) {
  const cardRef = useRef<HTMLDivElement | null>(null);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const card = cardRef.current;
    if (!card) return;

    const rect = card.getBoundingClientRect();
    const x = e.clientX - rect.left; // x coordinate inside element
    const y = e.clientY - rect.top;  // y coordinate inside element

    // Calculate rotation angles based on cursor position relative to center of element
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    const rotateY = ((x - centerX) / rect.width) * 28; // Up to 28 degrees Y tilt
    const rotateX = ((centerY - y) / rect.height) * 28; // Up to 28 degrees X tilt

    card.style.transform = `perspective(800px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-14px) scale(1.08)`;
    card.style.zIndex = '30';
  };

  const handleMouseLeave = () => {
    const card = cardRef.current;
    if (!card) return;
    
    // Return to the initial stylized tilt rotation
    card.style.transform = `rotate(${item.tilt}) translateY(0px) scale(1)`;
    card.style.zIndex = '1';
  };

  return (
    <motion.div
      ref={cardRef}
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-100px" }}
      transition={{ duration: 0.8, delay: idx * 0.08 }}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className="bg-white p-3 pb-8 w-[150px] sm:w-[170px] rounded-sm shadow-[0_12px_40px_rgba(107,26,42,0.12),0_4px_12px_rgba(0,0,0,0.06)] border border-amber-50/20 cursor-pointer transition-transform duration-300 ease-out flex-shrink-0"
      style={{
        transform: `rotate(${item.tilt})`,
        transformStyle: 'preserve-3d',
      }}
    >
      {/* Polaroid image window */}
      <div 
        className="w-full aspect-square rounded-sm bg-stone-100 bg-cover bg-center mb-4 border border-stone-200/45 filter contrast-[1.05]"
        style={{ backgroundImage: `url('${item.image}')` }}
      />
      
      {/* Caption text */}
      <p className="font-serif italic text-[11px] sm:text-xs text-stone-700 text-center tracking-wide leading-tight px-1 font-medium select-none truncate">
        {lang === 'en' ? item.captionEn : item.captionBn}
      </p>
    </motion.div>
  );
}
