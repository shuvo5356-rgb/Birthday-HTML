import { TranslationSet, TimelineEvent, GallerySlide, PolaroidPhoto, LoveNote } from './types';

const englishTranslation: TranslationSet = {
  title: "Happy Birthday Leona ❤️",
  subtitle: "A journey through our forever",
  lockHint: "hint: your beautiful name ❤️",
  lockError: "That's not right, my love...",
  lockInputPlaceholder: "Enter your name...",
  unlockButtonText: "→",
  enterWorld: "Enter our secret world",
  skipIntro: "Tap to continue →",
  musicBoxPlaying: "Music Box Active 🎵",
  musicBoxMuted: "Music Box Muted 🔇",
  dayTitle: "The day the world got brighter",
  bornText: "A star named Leona was born",
  calendarQuote: "Somewhere in July, the universe quietly created its most beautiful masterpiece.",
  heroEyebrow: "A love story · For you alone",
  heroTagline: "My heart's most beautiful chapter",
  scrollExplore: "Scroll to explore",
  countdownEyebrow: "Counting every moment",
  countdownTitle: "Your Special Day",
  days: "Days",
  hours: "Hours",
  minutes: "Minutes",
  seconds: "Seconds",
  countdownMessage: "Every second that passes is another second I spend loving you more, Leona ❤️",
  timelineEyebrow: "Our love story",
  timelineTitle: "How We Became Us",
  galleryEyebrow: "Captured moments",
  galleryTitle: "Our Photo Gallery",
  polaroidEyebrow: "Floating memories",
  polaroidTitle: "Our Polaroid Wall",
  loveWorldEyebrow: "Somewhere on this earth",
  loveWorldTitle: "A World Made of Notes for You",
  loveWorldIntro: "Out of this whole spinning planet, my heart found exactly one person worth writing to, again and again.",
  noteWallAddPlaceholder: "Write a love response, Leona...",
  noteWallAddBtn: "Pin to Wall 📌",
  letterEyebrow: "Only for your eyes",
  letterTitle: "A Secret Letter for You",
  letterBtn: "Open with love",
  letterGreeting: "My dearest Leona, my Pakhi,",
  letterSign: "Forever yours,\nSadiq ❤️",
  cakeEyebrow: "Make a wish",
  cakeTitle: "Blow the Candle",
  cakeBtn: "Blow the Candle 🕯️",
  cakeInstruction: "Click the cake or button to blow the candle!",
  cakeSuccess: "Make a wish, Leona! Your wish will come true! 🌟",
  particleHeartEyebrow: "Every particle of me",
  particleHeartTitle: "Beats For You",
  particleHeartDesc: "Ten thousand tiny lights, all moving as one — just like every part of me moves toward you, Leona.",
  finaleTitle: "Happy Birthday\nMy Love",
  finaleSubtitle: "\"I Love You Forever, Pakhi\"",
  finaleSignature: "— With all my love, Sadiq",
  celebrateBtn: "🎆 Celebrate!"
};

export const translations: Record<'en' | 'bn', TranslationSet> = {
  en: englishTranslation,
  bn: englishTranslation // No translation option, both fallback to premium English!
};

export const timelineEvents: TimelineEvent[] = [
  {
    emoji: "✨",
    dateEn: "The Beginning",
    dateBn: "The Beginning",
    titleEn: "The First Hello",
    titleBn: "The First Hello",
    textEn: "We first talked on Ome TV — just a random connection, a random chance, on an ordinary day that turned into the most important one. I still remember it clearly, even now. If that day had never happened, maybe we would never have come this far together. I feel so lucky that out of everyone in the world, that one chance found you.",
    textBn: "We first talked on Ome TV — just a random connection, a random chance, on an ordinary day that turned into the most important one. I still remember it clearly, even now. If that day had never happened, maybe we would never have come this far together. I feel so lucky that out of everyone in the world, that one chance found you."
  },
  {
    emoji: "💬",
    dateEn: "First Conversations",
    dateBn: "First Conversations",
    titleEn: "When Words Became Magic",
    titleBn: "When Words Became Magic",
    textEn: "We talked for hours and hours. Every conversation felt like discovering a new universe. I kept thinking — how can one person be this perfect?",
    textBn: "We talked for hours and hours. Every conversation felt like discovering a new universe. I kept thinking — how can one person be this perfect?"
  },
  {
    emoji: "💫",
    dateEn: "The Moments",
    dateBn: "The Moments",
    titleEn: "Our Favourite Memories",
    titleBn: "Our Favourite Memories",
    textEn: "My favourite memory will always be the first time we met in person. Everything about that day was beautiful — the moment, the time, the songs playing, the sky above us, and you standing right there. It felt absolutely perfect, like the world had arranged itself just for us. It's a day I will never forget.",
    textBn: "My favourite memory will always be the first time we met in person. Everything about that day was beautiful — the moment, the time, the songs playing, the sky above us, and you standing right there. It felt absolutely perfect, like the world had arranged itself just for us. It's a day I will never forget."
  },
  {
    emoji: "🌹",
    dateEn: "Right Now",
    dateBn: "Right Now",
    titleEn: "Today, Your Birthday",
    titleBn: "Today, Your Birthday",
    textEn: "Today the whole world should stop and celebrate — because the most wonderful person was born on this day. And I am the luckiest human alive to know you.",
    textBn: "Today the whole world should stop and celebrate — because the most wonderful person was born on this day. And I am the luckiest human alive to know you."
  },
  {
    emoji: "🌅",
    dateEn: "Forever & Beyond",
    dateBn: "Forever & Beyond",
    titleEn: "Our Future Together",
    titleBn: "Our Future Together",
    textEn: "Every dream I have for the future has you in it. A thousand more birthdays, a thousand more memories — all with you, my Leona, my Pakhi ❤️",
    textBn: "Every dream I have for the future has you in it. A thousand more birthdays, a thousand more memories — all with you, my Leona, my Pakhi ❤️"
  }
];

export const gallerySlides: GallerySlide[] = [
  {
    image: 'https://i.ibb.co.com/203s09Pd/IMG-1980.avif',
    captionEn: "The day everything changed",
    captionBn: "The day everything changed",
    num: "01"
  },
  {
    image: 'https://i.ibb.co.com/BVZkYnGx/IMG-1986.avif',
    captionEn: "That smile that melts my heart",
    captionBn: "That smile that melts my heart",
    num: "02"
  },
  {
    image: 'https://i.ibb.co.com/YFLktYHm/IMG-1440.avif',
    captionEn: "Laughing together endlessly",
    captionBn: "Laughing together endlessly",
    num: "03"
  },
  {
    image: 'https://i.ibb.co.com/ZpLxXtMM/IMG-1700.avif',
    captionEn: "A perfect evening with you",
    captionBn: "A perfect evening with you",
    num: "04"
  },
  {
    image: 'https://i.ibb.co.com/fzQp282B/IMG-1436.avif',
    captionEn: "Your eyes in the golden light",
    captionBn: "Your eyes in the golden light",
    num: "05"
  },
  {
    image: 'https://i.ibb.co.com/XR8r2xh/422d8301-96db-42e3-92ac-074ca56bb782.jpg',
    captionEn: "When you laughed at my joke",
    captionBn: "When you laughed at my joke",
    num: "06"
  },
  {
    image: 'https://i.ibb.co.com/G3JjFNGj/IMG-1005.avif',
    captionEn: "Late night conversations",
    captionBn: "Late night conversations",
    num: "07"
  },
  {
    image: 'https://i.ibb.co.com/1fYXSf03/IMG-1002.avif',
    captionEn: "You are my greatest treasure",
    captionBn: "You are my greatest treasure",
    num: "08"
  }
];

export const polaroidPhotos: PolaroidPhoto[] = [
  {
    image: 'https://i.ibb.co.com/5NK4VG3/IMG-6109.avif',
    captionEn: "First rose",
    captionBn: "First rose",
    tilt: "-4deg",
    delay: "0.1s"
  },
  {
    image: 'https://i.ibb.co.com/d4Ybd2GZ/IMG-8759.jpg',
    captionEn: "That smile",
    captionBn: "That smile",
    tilt: "3deg",
    delay: "0.2s"
  },
  {
    image: 'https://i.ibb.co.com/7t8ZDp6q/IMG-8682.jpg',
    captionEn: "Magic night",
    captionBn: "Magic night",
    tilt: "-2deg",
    delay: "0.3s"
  },
  {
    image: 'https://i.ibb.co.com/203s09Pd/IMG-1980.avif',
    captionEn: "Spring day",
    captionBn: "Spring day",
    tilt: "5deg",
    delay: "0.4s"
  },
  {
    image: 'https://i.ibb.co.com/BVZkYnGx/IMG-1986.avif',
    captionEn: "Always us",
    captionBn: "Always us",
    tilt: "-6deg",
    delay: "0.5s"
  },
  {
    image: 'https://i.ibb.co.com/YFLktYHm/IMG-1440.avif',
    captionEn: "Moonlight",
    captionBn: "Moonlight",
    tilt: "2deg",
    delay: "0.6s"
  },
  {
    image: 'https://i.ibb.co.com/ZpLxXtMM/IMG-1700.avif',
    captionEn: "Sparkle",
    captionBn: "Sparkle",
    tilt: "-3deg",
    delay: "0.7s"
  },
  {
    image: 'https://i.ibb.co.com/fzQp282B/IMG-1436.avif',
    captionEn: "Free",
    captionBn: "Free",
    tilt: "4deg",
    delay: "0.8s"
  },
  {
    image: 'https://i.ibb.co.com/G3JjFNGj/IMG-1005.avif',
    captionEn: "My gem",
    captionBn: "My gem",
    tilt: "-5deg",
    delay: "0.9s"
  },
  {
    image: 'https://i.ibb.co.com/1fYXSf03/IMG-1002.avif',
    captionEn: "In bloom",
    captionBn: "In bloom",
    tilt: "1deg",
    delay: "1.0s"
  }
];

export const initialNotes: LoveNote[] = [
  { id: '1', text: "I love how you care so deeply, even in the smallest things.", author: "Sadiq", tilt: -2 },
  { id: '2', text: "You have the softest heart, and that will always be my favourite thing about you, Leona.", author: "Sadiq", tilt: 1.5 },
  { id: '3', text: "Your overthinking only reminds me how much you care.", author: "Sadiq", tilt: -1 },
  { id: '4', text: "You make ordinary moments feel beautiful without even trying.", author: "Sadiq", tilt: 2 },
  { id: '5', text: "Thank you for staying and choosing us.", author: "Sadiq", tilt: -1.5 },
  { id: '6', text: "You are my comfort, my peace, and my favourite place.", author: "Sadiq", tilt: 1 },
  { id: '7', text: "I hope you always see yourself the way I see you.", author: "Sadiq", tilt: -2.5 },
  { id: '8', text: "Happy Birthday to the girl who made my world softer.", author: "Sadiq", tilt: 2.5 },
  { id: '9', text: "Forever wouldn't feel long enough with you. ♡", author: "Sadiq", tilt: -1 }
];
