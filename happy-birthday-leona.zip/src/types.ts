export type Language = 'en' | 'bn';

export interface TranslationSet {
  title: string;
  subtitle: string;
  lockHint: string;
  lockError: string;
  lockInputPlaceholder: string;
  unlockButtonText: string;
  enterWorld: string;
  skipIntro: string;
  musicBoxPlaying: string;
  musicBoxMuted: string;
  dayTitle: string;
  bornText: string;
  calendarQuote: string;
  heroEyebrow: string;
  heroTagline: string;
  scrollExplore: string;
  countdownEyebrow: string;
  countdownTitle: string;
  days: string;
  hours: string;
  minutes: string;
  seconds: string;
  countdownMessage: string;
  timelineEyebrow: string;
  timelineTitle: string;
  galleryEyebrow: string;
  galleryTitle: string;
  polaroidEyebrow: string;
  polaroidTitle: string;
  loveWorldEyebrow: string;
  loveWorldTitle: string;
  loveWorldIntro: string;
  noteWallAddPlaceholder: string;
  noteWallAddBtn: string;
  letterEyebrow: string;
  letterTitle: string;
  letterBtn: string;
  letterGreeting: string;
  letterSign: string;
  cakeEyebrow: string;
  cakeTitle: string;
  cakeBtn: string;
  cakeInstruction: string;
  cakeSuccess: string;
  particleHeartEyebrow: string;
  particleHeartTitle: string;
  particleHeartDesc: string;
  finaleTitle: string;
  finaleSubtitle: string;
  finaleSignature: string;
  celebrateBtn: string;
}

export interface TimelineEvent {
  emoji: string;
  dateEn: string;
  dateBn: string;
  titleEn: string;
  titleBn: string;
  textEn: string;
  textBn: string;
}

export interface GallerySlide {
  image: string;
  captionEn: string;
  captionBn: string;
  num: string;
}

export interface PolaroidPhoto {
  image: string;
  captionEn: string;
  captionBn: string;
  tilt: string;
  delay: string;
}

export interface LoveNote {
  id: string;
  text: string;
  author: string;
  tilt: number;
}
