// Custom audio manager with support for custom MP3 files and beautiful Web Audio API fallback.
// This allows the user to simply save 'music.mp3' and 'candle-blow.mp3' in the public folder,
// while ensuring a beautiful experience even if the files are not uploaded or fail to load.

class BirthdayAudioSynth {
  private ctx: AudioContext | null = null;
  private isPlaying: boolean = false;
  private timerId: number | null = null;
  private currentNoteIndex: number = 0;
  
  // HTML5 Audio Elements
  private bgAudio: HTMLAudioElement | null = null;
  private blowAudio: HTMLAudioElement | null = null;
  private useSynthBg: boolean = false;

  // A beautiful ambient, arpeggiated piano/music-box melody in C major / Fmaj7 / G6 / Am9
  private melodyNotes: number[] = [
    // Fmaj7 arpeggio (C4, E4, F4, A4, C5)
    261.63, 329.63, 349.23, 440.00, 523.25, 440.00, 349.23, 329.63,
    // G6 arpeggio (B3, D4, G4, B4, D5)
    246.94, 293.66, 392.00, 493.88, 587.33, 493.88, 392.00, 293.66,
    // Am9 arpeggio (A3, C4, E4, G4, B4, C5)
    220.00, 261.63, 329.63, 392.00, 493.88, 523.25, 493.88, 392.00,
    // Em7 arpeggio (G3, B3, E4, G4, B4)
    196.00, 246.94, 329.63, 392.00, 493.88, 392.00, 329.63, 246.94
  ];

  private noteSpacing = 0.35;

  constructor() {}

  private initAudio() {
    // Initialize HTML5 Audio elements
    if (!this.bgAudio) {
      this.bgAudio = new Audio('/music.mp3');
      this.bgAudio.loop = true;
      this.bgAudio.volume = 0.35; // default volume
      
      // If the audio file fails to decode or load (like our placeholder or a missing file),
      // we gracefully mark it to fallback to the Web Audio synth.
      this.bgAudio.addEventListener('error', () => {
        console.warn("Background music file error, falling back to Web Audio Synthesizer.");
        this.useSynthBg = true;
        if (this.isPlaying) {
          this.startSynth();
        }
      });
    }

    if (!this.blowAudio) {
      this.blowAudio = new Audio('/candle-blow.mp3');
      this.blowAudio.addEventListener('error', () => {
        console.warn("Candle blow audio file error. Fallback sound will be used.");
      });
    }

    // Initialize Web Audio context safely
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      this.ctx = new AudioCtx();
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public start() {
    this.initAudio();
    if (this.isPlaying) return;
    this.isPlaying = true;

    // Try playing the background music file first
    if (this.bgAudio && !this.useSynthBg) {
      this.bgAudio.play()
        .then(() => {
          console.log("Successfully playing music.mp3 background romantic track.");
        })
        .catch((err) => {
          console.warn("Failed to play music.mp3 directly. Starting synthesized melody instead:", err);
          this.useSynthBg = true;
          this.startSynth();
        });
    } else {
      this.startSynth();
    }
  }

  private startSynth() {
    if (!this.isPlaying) return;
    this.currentNoteIndex = 0;
    this.scheduleNextNotes();
  }

  public stop() {
    this.isPlaying = false;
    
    // Stop MP3 if playing
    if (this.bgAudio) {
      this.bgAudio.pause();
    }

    // Stop synth scheduler
    if (this.timerId) {
      clearTimeout(this.timerId);
      this.timerId = null;
    }
  }

  private scheduleNextNotes() {
    if (!this.isPlaying || !this.ctx || !this.useSynthBg) return;

    const now = this.ctx.currentTime;
    const freq = this.melodyNotes[this.currentNoteIndex];
    this.playTone(freq, now, 1.8);

    this.currentNoteIndex = (this.currentNoteIndex + 1) % this.melodyNotes.length;

    this.timerId = window.setTimeout(() => {
      this.scheduleNextNotes();
    }, this.noteSpacing * 1000);
  }

  private playTone(freq: number, startTime: number, duration: number) {
    if (!this.ctx) return;

    const osc = this.ctx.createOscillator();
    const gainNode = this.ctx.createGain();
    const filter = this.ctx.createBiquadFilter();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(freq, startTime);

    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(1200, startTime);
    filter.Q.setValueAtTime(1, startTime);

    gainNode.gain.setValueAtTime(0, startTime);
    gainNode.gain.linearRampToValueAtTime(0.08, startTime + 0.05);
    gainNode.gain.exponentialRampToValueAtTime(0.0001, startTime + duration);

    osc.connect(filter);
    filter.connect(gainNode);
    gainNode.connect(this.ctx.destination);

    const delayOsc = this.ctx.createOscillator();
    const delayGain = this.ctx.createGain();
    
    delayOsc.type = 'sine';
    delayOsc.frequency.setValueAtTime(freq, startTime + 0.25);
    
    delayGain.gain.setValueAtTime(0, startTime + 0.25);
    delayGain.gain.linearRampToValueAtTime(0.02, startTime + 0.3);
    delayGain.gain.exponentialRampToValueAtTime(0.0001, startTime + 0.25 + duration * 0.8);

    delayOsc.connect(delayGain);
    delayGain.connect(this.ctx.destination);

    osc.start(startTime);
    osc.stop(startTime + duration);

    delayOsc.start(startTime + 0.25);
    delayOsc.stop(startTime + 0.25 + duration * 0.8);
  }

  // Blow sound effect with elegant background music ducking
  public playCandleBlowEffect() {
    this.initAudio();

    const prevVolume = this.bgAudio ? this.bgAudio.volume : 0.35;
    if (this.bgAudio) {
      this.bgAudio.volume = 0.1; // Duck the volume of the background music
    }

    let playSuccess = false;

    // Try playing the custom candle-blow.mp3 file
    if (this.blowAudio) {
      this.blowAudio.volume = 1.0;
      this.blowAudio.currentTime = 0;
      this.blowAudio.play()
        .then(() => {
          console.log("Playing candle-blow.mp3 successfully.");
          playSuccess = true;
        })
        .catch((err) => {
          console.warn("Failed to play custom candle-blow.mp3. Using beautiful synthesizer sounds:", err);
          this.playSynthBlowEffect();
        });

      this.blowAudio.onended = () => {
        if (this.bgAudio) {
          this.bgAudio.volume = prevVolume; // Restore original background music volume
        }
      };
    } else {
      this.playSynthBlowEffect();
      // Fallback restore original volume after 2 seconds
      setTimeout(() => {
        if (this.bgAudio) {
          this.bgAudio.volume = prevVolume;
        }
      }, 2000);
    }

    // Layer the synth chime effect quietly for extra magic!
    setTimeout(() => {
      this.playSynthChimeOnly();
    }, 300);
  }

  private playSynthChimeOnly() {
    if (!this.ctx) return;
    const now = this.ctx.currentTime;
    const chimes = [523.25, 659.25, 783.99, 1046.50, 1318.51, 1567.98];
    chimes.forEach((freq, idx) => {
      const chimeTime = now + idx * 0.04;
      const chimeOsc = this.ctx!.createOscillator();
      const chimeGain = this.ctx!.createGain();

      chimeOsc.type = 'sine';
      chimeOsc.frequency.setValueAtTime(freq, chimeTime);

      chimeGain.gain.setValueAtTime(0, chimeTime);
      chimeGain.gain.linearRampToValueAtTime(0.04, chimeTime + 0.01);
      chimeGain.gain.exponentialRampToValueAtTime(0.0001, chimeTime + 0.8);

      chimeOsc.connect(chimeGain);
      chimeGain.connect(this.ctx!.destination);

      chimeOsc.start(chimeTime);
      chimeOsc.stop(chimeTime + 0.85);
    });
  }

  private playSynthBlowEffect() {
    if (!this.ctx) return;
    const now = this.ctx.currentTime;

    // White noise "whoosh" representing candle blowing
    const bufferSize = this.ctx.sampleRate * 0.6;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }

    const noiseNode = this.ctx.createBufferSource();
    noiseNode.buffer = buffer;

    const noiseFilter = this.ctx.createBiquadFilter();
    noiseFilter.type = 'bandpass';
    noiseFilter.frequency.setValueAtTime(1000, now);
    noiseFilter.frequency.exponentialRampToValueAtTime(100, now + 0.5);
    noiseFilter.Q.setValueAtTime(5, now);

    const noiseGain = this.ctx.createGain();
    noiseGain.gain.setValueAtTime(0.25, now);
    noiseGain.gain.linearRampToValueAtTime(0.15, now + 0.1);
    noiseGain.gain.exponentialRampToValueAtTime(0.001, now + 0.5);

    noiseNode.connect(noiseFilter);
    noiseFilter.connect(noiseGain);
    noiseGain.connect(this.ctx.destination);
    noiseNode.start(now);

    // Beautiful rising chime cascade
    const chimes = [523.25, 587.33, 659.25, 783.99, 880.00, 1046.50, 1174.66, 1318.51, 1567.98, 1760.00];
    chimes.forEach((freq, idx) => {
      const chimeTime = now + 0.1 + idx * 0.05;
      const chimeOsc = this.ctx!.createOscillator();
      const chimeGain = this.ctx!.createGain();

      chimeOsc.type = 'sine';
      chimeOsc.frequency.setValueAtTime(freq, chimeTime);

      chimeGain.gain.setValueAtTime(0, chimeTime);
      chimeGain.gain.linearRampToValueAtTime(0.08, chimeTime + 0.01);
      chimeGain.gain.exponentialRampToValueAtTime(0.0001, chimeTime + 1.2);

      chimeOsc.connect(chimeGain);
      chimeGain.connect(this.ctx!.destination);

      chimeOsc.start(chimeTime);
      chimeOsc.stop(chimeTime + 1.25);
    });
  }
}

export const audioSynth = new BirthdayAudioSynth();
